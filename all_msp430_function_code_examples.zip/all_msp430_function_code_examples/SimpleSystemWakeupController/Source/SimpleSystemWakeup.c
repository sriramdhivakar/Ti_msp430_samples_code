/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Demo - RTC, Interrupt Host at Predetermined Time
//
//  Description: Configure ACLK to use XT1 as RTC source clock,
//               ACLK = XT1 = ~32768kHz, MCLK = SMCLK = default DCODIV = ~1MHz.
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |          P1.0 |---> Host (Interrupt Host)
//        |               |
//        |          P1.3 |<--  Host (Start RTC)
//        |               |
//        |           P2.6|--> XOUT 32768 XTAL
//        |           P2.7|<-- XIN
//
//   Jace Hall
//   Texas Instruments Inc.
//   July 2017
//   Built with Code Composer Studio v7.2 and IAR 7.10
//******************************************************************************
#include <msp430.h>

/* Global Variables */
#if defined(__IAR_SYSTEMS_ICC__)
__persistent volatile unsigned char timeIncrement = 0; //Software Count Variable
 #elif defined(__TI_COMPILER_VERSION__)
#pragma PERSISTENT(timeIncrement)
volatile unsigned char timeIncrement = 0;              //Software Count Variable
#endif

/* Constant Definitions */
#define INCREMENT 0  // Software Count Interval, change this to increase
                     // Wake-up Time.
/**
 * RTC Count Initialization
 * 1024/32768 * 32 = 1 sec.
 * 30 minutes = 1800 sec. 1800 *32 = 57,600. (57600-1) to hex = 0xE0FF.
 * Wake-up in seconds is equal to (RTCMOD/32) * INCREMENT
 */
#define MODCOUNT (32-1)*10 //Value of RTCMOD Register.
                       //Every 32 counts is 1 second. Value 0xE0FF is 30 minutes

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;        // Stop watchdog timer

    // Configure GPIO
    P1OUT = 0x00;                 // Clear P1.0 output latch /P1.3 Pulldown
    P1DIR = ~BIT3;                   // Set P1.3 to input direction
    P2OUT = 0x00;                    // Unused pins to LP State
    P2DIR = 0xFF;
    P2SEL1 = BIT6 | BIT7;            // P2.6~P2.7: crystal pins
    SYSCFG0 = FRWPPW;            // Enable FRAM write access

    PM5CTL0 &= ~LOCKLPM5; // Disable the GPIO power-on default high-impedance
                         // mode to activate previously configured port settings
    // Initialize crystal
    do
    {
        CSCTL7 = 0;             // Clear XT1 fault flag
        SFRIFG1 = 0;            // Clear fault flag
    } while (SFRIFG1 & OFIFG);  // Test oscillator fault flag


    // First determine whether we are coming out of an LPMx.5 or a regular RESET
    if (SYSRSTIV == SYSRSTIV_LPM5WU)        // When woken up from LPM3.5, reinit
    {
        __enable_interrupt();
        __no_operation();
        __no_operation();
    }
    else
    {
        // Device powered up from a cold start.
        // It configures the device and puts the device into LPM3
        // Waiting for GPIO Interrupt
        P1REN = BIT3;                    // P1.3 pull-down register enable
        P1IES = 0x00;                    // P1.3 Low/High edge
        P1IE  = BIT3;                    // P1.3 interrupt enabled
        CSCTL4 = SELA__XT1CLK;           // Set ACLK = XT1CLK = 32768Hz
    }
    P1IE  = BIT3;                    // P1.3 interrupt enabled
    __bis_SR_register(LPM3_bits | GIE);     // Enter LPM3, enable interrupt
}

/**
* RTC interrupt service routine
*/

#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
    switch(__even_in_range(RTCIV,RTCIV__RTCIFG))
    {
        case  RTCIV__NONE:   break;          // No interrupt
        case  RTCIV__RTCIFG:                 // RTC Overflow
            if(timeIncrement >= INCREMENT)
                {
                    P1OUT = BIT0;                // Wake-up Host Controller
                    timeIncrement =0;            // Clear Software Counter
                    P1IE = BIT3;                 // Enable RTC STart Interrupt
                    RTCCTL = RTCSS_2 | RTCSR | RTCPS__1024; //Stop RTC
                    P1OUT = 0;
                }
                else
                {
                    timeIncrement++ ;     // Increment Software Counter
                }
            // Enter LPM3.5 mode with interrupts enabled. Note that this
            //operation does not return. The LPM3.5 will exit through a
            //RESETevent, resulting in a re-start of the code.
             PMMCTL0_H = PMMPW_H;         // Open PMM Registers for write
             PMMCTL0_L |= PMMREGOFF;      // and set PMMREGOFF
             __bis_SR_register_on_exit(LPM3_bits | GIE);
             __no_operation();
               break;
        default: break;
    }
}

/**
* Port 1 interrupt service routine
*/

#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    timeIncrement = 0;                        //Clear Software Counter
    RTCMOD = MODCOUNT;
    // Source  = XT1, divided by 1024, Start RTC
    RTCCTL = RTCSS_2 | RTCSR | RTCPS__1024 | RTCIE;
    P1IE  = 0x00;
    P1IFG = 0x00;                            //Clear P1.3 IFG
    // Enter LPM3.5 mode with interrupts enabled. Note that this
    //operation does not return. The LPM3.5 will exit through a RESET
    //event, resulting in a re-start of the code.
     PMMCTL0_H = PMMPW_H;                // Open PMM Registers for write
     PMMCTL0_L |= PMMREGOFF;             // and set PMMREGOFF
     __bis_SR_register_on_exit(LPM3_bits | GIE);
     __no_operation();
}

/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Single-wire Host Communication
//
//  Description: This master code demonstrates single-wire protocol using a
//  MSP430FR2000 device.  Functionality and optimizations have been limited
//  due to size restrictions but can be increased if using an FRAM device with
//  more main memory.  Pull-up resistance, register commands, and protocol
//  timing may vary by slave device, and as such the datasheet should be
//  referenced.  Please see the associated document for more information.
//
//                                /|\
//               MSP430FR2000      2.2k
//                   host          |
//             -----------------   |
//            |        P1.5/GPIO|<-|->Single-wire slave IO
//            |                 |
//
//   R. Brown
//   Texas Instruments Inc.
//   July 2017
//   Built with Code Composer Studio Version: 7.1
//******************************************************************************

#include <msp430.h> 
#include <stdint.h>
//------------------------------------------------------------------------------
// Single-wire commands Registers
//------------------------------------------------------------------------------
#define READ_ROM            0x33                // Read ROM command
#define MATCH_ROM           0x55                // Match ROM command
#define SKIP_ROM            0xCC                // Skip ROM command

#define WRITE_MEM           0x0F                // Write memory command
#define VERITY_MEM          0xAA                // Verify memory command
#define COPY_MEM            0x55                // Copy memory command
#define READ_MEM            0xF0                // Read memory command

//------------------------------------------------------------------------------
// Define the SMCLK frequency
//------------------------------------------------------------------------------
#define CLKFREQ     16u                         // Timer clock frequency (Hz)
//------------------------------------------------------------------------------
// Define Single-wire Protocol Related Timing Constants
//------------------------------------------------------------------------------
#define RESET_LOW    (500 * CLKFREQ)            // Set line low (500us)
#define RESET_DETECT (80 * CLKFREQ)             // Reset detect (80us)
#define RESET_DELAY  (360 * CLKFREQ)            // Reset delay (280us)

#define WRITE_ONE    (6 * CLKFREQ)              // Write byte 1 (6us)
#define DELAY_ONE    (64 * CLKFREQ)             // Write delay 1 (64us)
#define WRITE_ZERO   (60 * CLKFREQ)             // Write byte 0 (60us)
#define DELAY_ZERO   (10 * CLKFREQ)             // Write delay 0 (10us)

#define READ_LOW     (6 * CLKFREQ)              // Set line low (6us)
#define READ_DETECT  (9 * CLKFREQ)              // Slave response (9us)
#define READ_DELAY   (55 * CLKFREQ)             // Slave release (55us)

//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------
void Single_reset(void);
void Single_write(uint8_t);
uint8_t Single_read(void);

//------------------------------------------------------------------------------
void main(void)
{
  uint8_t identification[8] = {0x00};           // 64-bit identification number
  uint8_t byte;                                 // 8-byte counter

  WDTCTL = WDTPW | WDTHOLD;                     // Stop watchdog timer

  __bis_SR_register(SCG0);                      // disable FLL
  CSCTL3 |= SELREF__REFOCLK;                    // Set REFO as FLL reference source
  CSCTL0 = 0;                                   // clear DCO and MOD registers
  CSCTL1 &= ~(DCORSEL_7);                       // Clear DCO frequency select bits first
  CSCTL1 |= DCORSEL_5;                          // Set DCO = 16MHz
  CSCTL2 = FLLD_0 + 487;                        // DCODIV = 16MHz
  __delay_cycles(3);
  __bic_SR_register(SCG0);                      // enable FLL
  while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));    // Poll until FLL is locked

  // Disable the GPIO power-on default high-impedance mode
  // to activate previously configured port settings
  PM5CTL0 &= ~LOCKLPM5;

  P1OUT = BIT5;                                 // P1.5 output high
  P1DIR = 0xFF;                                 // P1.5 as output

  Single_reset();                               // Send reset
  Single_write(READ_ROM);                       // Send Read ROM command
  for (byte = 0; byte < 8; byte++)
      identification[byte] = Single_read();     // Read full identification number

  while (1)
  {
      __bis_SR_register(LPM3_bits);             // Place application code here
  }
}

//------------------------------------------------------------------------------
// void Single_reset(void)
//
// Perform a single-wire reset
//------------------------------------------------------------------------------
void Single_reset(void)
{
    P1OUT = 0x00;                               // P1.5 driven low
    __delay_cycles(RESET_LOW);                  // Set delay
    P1DIR = 0x00;                               // P1.5 input
    __delay_cycles(RESET_DELAY);                // Set delay
    P1OUT = BIT5;                               // Reset P1.5 to output high
    P1DIR = BIT5;
}

//------------------------------------------------------------------------------
// void Single_write(unsigned uint8_t Data)
//
// Write the 8-bit word 'Data' to the Single-wire enabled device.
//------------------------------------------------------------------------------
void Single_write(uint8_t Data)
{
    uint8_t bit;                                // Initialize bit counter
    for (bit = 0; bit < 8; bit++)               // Loop 8 bits to write a byte
    {
        P1OUT = 0x00;                           // Set P1.5 low
        if((Data >> bit) & 0x01)                // If bit is a 1
        {
            __delay_cycles(WRITE_ONE);          // Set delay
            P1OUT = BIT5;                       // Set P1.5 back to high
            __delay_cycles(DELAY_ONE);          // Set delay
        }
        else                                    // Else if a 0
        {
            __delay_cycles(WRITE_ZERO);         // Set delay
            P1OUT = BIT5;                       // Set P1.5 back to high
            __delay_cycles(DELAY_ZERO);         // Set delay
        }
    }
}

//------------------------------------------------------------------------------
// unsigned uint8_t Single_read(unsigned uint8_t Data)
//
// Read the 8-bit word 'Data' from the Single-wire enabled device
//------------------------------------------------------------------------------
uint8_t Single_read(void)
{
    uint8_t bit;                                // Initialize bit counter
    uint8_t Data = 0;                           // Initialize return data byte
    for (bit = 0; bit < 8; bit++)               // Loop 8 bits to read a byte
    {
        P1OUT = 0x00;                           // P1.5 driven low
        __delay_cycles(READ_LOW);               // Set delay
        P1DIR = 0x00;                           // P1.5 input
        __delay_cycles(READ_DETECT);            // Set delay
        if(P1IN & BIT5) Data |= (0x01 << bit);  // If high then read 1, else 0
        __delay_cycles(READ_DELAY);             // Set delay
        P1OUT = BIT5;                           // Reset P1.5 to output high
        P1DIR = BIT5;
    }
    return Data;                                // Return byte
}


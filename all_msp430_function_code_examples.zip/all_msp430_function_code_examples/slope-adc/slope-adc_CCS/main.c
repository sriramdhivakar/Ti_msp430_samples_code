/* --COPYRIGHT--,BSD-3-Clause
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Slope A/D Converter Demo
//
//  Description: Resistive Elements Measurement Using Slope A/D Converter.
//  Measure the discharge time of an known value capacitor through the resistor
//  to be measured (Rsense) and the reference resisitor (Rref). By comparing
//  the Rsense??s capacitor discharge time to that of Rref, then Rsense can be
//  easily calculated by simple ratio: Rsens = Rref * Tsens / Tref;
//  For more details, refer to application note SLAA129B
//
//  XT1 is considered to be absent in this example.
//  ACLK = default REFO ~32768Hz, MCLK = SMCLK = 16MHz.
//
//                    MSP430FR2000
//                 ------------------
//             /|\|                  |
//              | |                  |
//              --|RST               |
//                |             P1.2 |---------+
//                |                  |         |
//                |             P1.0 |---+     |
//                |                  |   |     |
//                |                  |  10K  Rsens
//                |                  |   |     |
//                |          P1.1/C1 |---+-----+
//                |                  |   |
//                |                  | 0.1uF
//                |                  |   |
//                |                  |  \|/
//                |                  |  GND
//
//   Ling Zhu
//   Texas Instruments Inc.
//   Aug. 2017
//   Built with IAR Embedded Workbench v7.20 & Code Composer Studio v7.20
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

// unsigned int R_table[100];                       // For debug purpose

int main(void)
{
//    uint8_t i = 0;
    uint16_t ui16Tref, ui16Tsens;
    volatile uint16_t ui16Rsens;
    const uint16_t ui16Rref = 10000;

    WDTCTL = WDTPW | WDTHOLD;                       // stop watchdog timer

    PM5CTL0 &= ~LOCKLPM5;                           // Disable the GPIO power-on default high-impedance mode
                                                    // to activate previously configured port settings


    FRCTL0 = FRCTLPW | NWAITS_1;                    // Configure one FRAM waitstate as required by the device datasheet for MCLK
                                                    // operation beyond 8MHz _before_ configuring the clock system.

    __bis_SR_register(SCG0);                        // disable FLL
    CSCTL3 = SELREF__REFOCLK;                       // Set REFO as FLL reference source
    CSCTL0 = 0;                                     // clear DCO and MOD registers
    CSCTL1 = 0x3B;                                  // Set DCO range = 16MHz
    CSCTL2 = FLLD_0 + 487;                          // DCOCLKDIV = 16MHz
    __delay_cycles(3);
    __bic_SR_register(SCG0);                        // enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));      // FLL locked

    /* eCOMP Init */
    P1SEL0 = BIT1;                                  // Select eCOMP input function on P1.1/C1
    P1SEL1 = BIT1;

    CPCTL0 = CPPSEL0 | CPNSEL1 | CPNSEL2 |CPPEN | CPNEN; // Select C1 as input for V+ terminal
                                                         // Select DAC as input for V- terminal
                                                         // Enable eCOMP input
    CPDACCTL |= CPDACEN;                            // Select VCC VREF and enable DAC
    CPDACDATA |= 0x010;                             // CPDACBUF1=On-chip VREF *16/64
    CPCTL1 |= CPEN | CPMSEL;                        // Turn on eCOMP, in low power mode

    /* Timer_B Init */
    TB0CCR0 = 229;                                  // Set 7ms charge time
    TB0CCTL1 = CM_2 | CCIS_1 | CAP | CCIE | SCS;
                                                    // Capture falling edge,
                                                    // Use CCI1B=eCOMP,
                                                    // Synchronous capture,
                                                    // Enable capture mode,
                                                    // Enable capture interrupt

    while(1)
    {
        P1DIR = BIT0;                               // Set P1.0 high to charge the capacitor
        P1OUT = BIT0;

        TB0CTL = TBSSEL__ACLK | MC__UP | TBCLR | TBIE;    // Use ACLK as clock source, clear TB0R

        __bis_SR_register(LPM3_bits + GIE);               // Enable interrupts. CPU is not required

        P1OUT = 0;                                  // Set P1.0 low to discharge the capacitor through Rref
        TB0CTL = TBSSEL__SMCLK | MC__CONTINUOUS | TBCLR;  // Use SMCLK as clock source, clear TB0R
                                                    // Start timer in continuous mode;

        __bis_SR_register(LPM0_bits);               // CPU is not required

        ui16Tref = TB0CCR1;                         // Get Rref discharge time

        P1OUT = BIT0;                               // Set P1.0 high to charge the capacitor

        TB0CTL = TBSSEL__ACLK | MC__UP | TBCLR | TBIE;   // Use ACLK as clock source, clear TB0R

        __bis_SR_register(LPM3_bits);               // CPU is not required

        P1DIR = BIT2;                               // Set P1.2 low to discharge the capacitor through Rsens
        P1OUT = 0;
        TB0CTL = TBSSEL__SMCLK | MC__CONTINUOUS | TBCLR; // Use SMCLK as clock source, clear TB0R
                                                    // Start timer in continuous mode;

        __bis_SR_register(LPM0_bits);               // CPU is not required

        ui16Tsens = TB0CCR1;                        // Get Rsens discharge time

        ui16Rsens = (uint32_t)ui16Rref * ui16Tsens / ui16Tref; // Calculate Rsens

//        R_table[i++] = ui16Rsens;                 // For debug purpose
//        if(i == 100)
//            while(1);

        __no_operation();                           // Set breakpoint here to watch Rsens value
    }
}

// Timer0_B3 Interrupt Vector (TBIV) handler
#pragma vector=TIMER0_B1_VECTOR
__interrupt void TIMER0_B1_ISR(void)
{
    TB0CTL = 0;
    TB0CCTL1 &= ~CCIFG;
    __bic_SR_register_on_exit(LPM3_bits);           // CPU active on reti
}

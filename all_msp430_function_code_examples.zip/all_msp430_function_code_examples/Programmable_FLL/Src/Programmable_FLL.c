/* --COPYRIGHT--,TI
 *MSP Source and Object Code Software License Agreement
 *
 *
 *IMPORTANT - PLEASE CAREFULLY READ THE FOLLOWING LICENSE AGREEMENT, WHICH IS LEGALLY BINDING.  AFTER YOU READ IT, YOU WILL BE ASKED WHETHER YOU ACCEPT AND AGREE TO ITS TERMS.  DO NOT CLICK  "I ACCEPT" UNLESS: (1) YOU WILL USE THE LICENSED MATERIALS FOR YOUR OWN BENEFIT AND PERSONALLY ACCEPT, AGREE TO AND INTEND TO BE BOUND BY THESE TERMS; OR (2) YOU ARE AUTHORIZED TO, AND INTEND TO BE BOUND BY, THESE TERMS ON BEHALF OF YOUR COMPANY.
 *
 *
 *Important - Read carefully: This Source and Object Code Software License Agreement ("Agreement") is a legal agreement between you and Texas Instruments Incorporated ("TI").  In this Agreement "you" means you personally if you will exercise the rights granted for your own benefit, but it means your company (or you on behalf of your company) if you will exercise the rights granted for your company's benefit.  The "Licensed Materials" subject to this Agreement include the software programs and any associated electronic documentation (in each case, in whole or in part) that accompany this Agreement, are set forth in the applicable software manifest and you access "on-line", as well as any updates or upgrades to such software programs or documentation, if any, provided to you at TI's sole discretion.  The Licensed Materials are specifically designed and licensed for use solely and exclusively with MSP microcontroller devices manufactured by or for TI ("TI Devices").  By installing, copying or otherwise using the Licensed Materials you agree to abide by the provisions set forth herein.  This Agreement is displayed for you to read prior to using the Licensed Materials.  If you choose not to accept or agree with these provisions, do not download or install the Licensed Materials.  
 *
 *Note Regarding Possible Access to Other Licensed Materials:  The Licensed Materials may be bundled with software and associated electronic documentation, if any, licensed under terms other than the terms of this Agreement (in whole or in part, "Other Licensed Materials"), including, for example Open Source Software and/or TI-owned or third party Proprietary Software licensed under such other terms.  "Open Source Software" means any software licensed under terms requiring that (A) other software ("Proprietary Software") incorporated, combined or distributed with such software or developed using such software: (i) be disclosed or distributed in source code form; or (ii) otherwise be licensed on terms inconsistent with the terms of this Agreement, including but not limited to permitting use of the Proprietary Software on or with devices other than TI Devices, or (B) require the owner of Proprietary Software to license any of its patents to users of the Open Source Software and/or Proprietary Software incorporated, combined or distributed with such Open Source Software or developed using such Open Source Software.  
 *
 *If by accepting this Agreement, you gain access to Other Licensed Materials, they will be listed in the applicable software manifest.  Your use of the Other Licensed Materials is subject to the applicable other licensing terms acknowledgements and disclaimers as specified in the applicable software manifest and/or identified or included with the Other Licensed Materials in the software bundle.  For clarification, this Agreement does not limit your rights under, or grant you rights that supersede, the terms of any applicable Other Licensed Materials license agreement.  If any of the Other Licensed Materials is Open Source Software that has been provided to you in object code only under terms that obligate TI to provide to you or show you where you can access the source code versions of such Open Source Software, TI will provide to you, or show you where you can access, such source code if you contact TI at Texas Instruments Incorporated, 12500 TI Boulevard, Mail Station 8638, Dallas, Texas 75243, Attention: Contracts Manager, Embedded Processing.  In the event you choose not to accept or agree with the terms in any applicable Other Licensed Materials license agreement, you must terminate this Agreement.
 *
 *1.	License Grant and Use Restrictions.
 *
 *a.	Licensed Materials License Grant.  Subject to the terms of this Agreement, TI hereby grants to you a limited, non-transferable, non-exclusive, non-assignable, non-sublicensable, fully paid-up and royalty-free license to:
 *
 *			i.	Limited Source Code License:  make copies, prepare derivative works, display internally and use internally the Licensed Materials provided to you in source code for the sole purpose of developing object and executable versions of such Licensed Materials, or any derivative thereof, that execute solely and exclusively on TI Devices, for end use in Licensee Products, and maintaining and supporting such Licensed Materials, or any derivative thereof, and Licensee Products.  For purposes of this Agreement, "Licensee Product" means a product that consists of both hardware, including one or more TI Devices, and software components, including only executable versions of the Licensed Materials that execute solely and exclusively on such TI Devices.
 *
 *			ii.	Object Code Evaluation, Testing and Use License:  make copies, display internally, distribute internally and use internally the Licensed Materials in object code for the sole purposes of evaluating and testing the Licensed Materials and designing and developing Licensee Products, and maintaining and supporting the Licensee Products;  
 *
 *			iii.	Demonstration License:  demonstrate to third parties the Licensed Materials executing solely and exclusively on TI Devices as they are used in Licensee Products, provided that such Licensed Materials are demonstrated in object or executable versions only and 
 *
 *		iv.	Production and Distribution License:  make, use, import, export and otherwise distribute the Licensed Materials as part of a Licensee Product, provided that such Licensee Products include only embedded executable copies of such Licensed Materials that execute solely and exclusively on TI Devices.
 *
 *	b.	Contractors.  The licenses granted to you hereunder shall include your on-site and off-site contractors (either an individual or entity), while such contractors are performing work for or providing services to you, provided that such contractors have executed work-for-hire agreements with you containing applicable terms and conditions consistent with the terms and conditions set forth in this Agreement and provided further that you shall be liable to TI for any breach by your contractors of this Agreement to the same extent as you would be if you had breached the Agreement yourself. 
 *
 *	c.	No Other License.  Nothing in this Agreement shall be construed as a license to any intellectual property rights of TI other than those rights embodied in the Licensed Materials provided to you by TI.  EXCEPT AS PROVIDED HEREIN, NO OTHER LICENSE, EXPRESS OR IMPLIED, BY ESTOPPEL OR OTHERWISE, TO ANY OTHER TI INTELLECTUAL PROPERTY RIGHTS IS GRANTED HEREIN.
 *
 *	d.	Covenant not to Sue.  During the term of this Agreement, you agree not to assert a claim against TI or its licensees that the Licensed Materials infringe your intellectual property rights.
 *
 *	e.	Restrictions.  You shall maintain the source code versions of the Licensed Materials under password control protection and shall not disclose such source code versions of the Licensed Materials, to any person other than your employees and contractors whose job performance requires access.  You shall not use the Licensed Materials with a processing device other than a TI Device, and you agree that any such unauthorized use of the Licensed Materials is a material breach of this Agreement.  You shall not use the Licensed Materials for the purpose of analyzing or proving infringement of any of your patents by either TI or TI's customers.  Except as expressly provided in this Agreement, you shall not copy, publish, disclose, display, provide, transfer or make available the Licensed Materials to any third party and you shall not sublicense, transfer, or assign the Licensed Materials or your rights under this Agreement to any third party.  You shall not mortgage, pledge or encumber the Licensed Materials in any way.  You may use the Licensed Materials with Open Source Software or with software developed using Open Source Software tools provided you do not incorporate, combine or distribute the Licensed Materials in a manner that subjects the Licensed Materials to any license obligations or any other intellectual property related terms of any license governing such Open Source Software. 
 *
 *	f.	Termination.  This Agreement is effective on the date the Licensed Materials are delivered to you together with this Agreement and will remain in full force and effect until terminated.  You may terminate this Agreement at any time by written notice to TI.  Without prejudice to any other rights, if you fail to comply with the terms of this Agreement or you are acquired, TI may terminate your right to use the Licensed Materials upon written notice to you.  Upon termination of this Agreement, you will destroy any and all copies of the Licensed Materials in your possession, custody or control and provide to TI a written statement signed by your authorized representative certifying such destruction. Except for Sections 1(a), 1(b) and 1(d), all provisions of this Agreement shall survive termination of this Agreement. 
 *
 *2.	Licensed Materials Ownership.  The Licensed Materials are licensed, not sold to you, and can only be used in accordance with the terms of this Agreement.  Subject to the licenses granted to you pursuant to this Agreement, TI and its licensors own and shall continue to own all right, title and interest in and to the Licensed Materials, including all copies thereof.  You agree that all fixes, modifications and improvements to the Licensed Materials conceived of or made by TI that are based, either in whole or in part, on your feedback, suggestions or recommendations are the exclusive property of TI and all right, title and interest in and to such fixes, modifications or improvements to the Licensed Materials will vest solely in TI.  Moreover, you acknowledge and agree that when your independently developed software or hardware components are combined, in whole or in part, with the Licensed Materials, your right to use the combined work that includes the Licensed Materials remains subject to the terms and conditions of this Agreement.
 *
 *3.	Intellectual Property Rights.  
 *
 *	a.	The Licensed Materials contain copyrighted material, trade secrets and other proprietary information of TI and its licensors and are protected by copyright laws, international copyright treaties, and trade secret laws, as well as other intellectual property laws.  To protect TI's and its licensors' rights in the Licensed Materials, you agree, except as specifically permitted by statute by a provision that cannot be waived by contract, not to "unlock", decompile, reverse engineer, disassemble or otherwise translate to a human-perceivable form any portions of the Licensed Materials provided to you in object code format only, nor permit any person or entity to do so.  You shall not remove, alter, cover, or obscure any confidentiality, trade secret, trade mark, patent, copyright or other proprietary notice or other identifying marks or designs from any component of the Licensed Materials and you shall reproduce and include in all copies of the Licensed Materials the copyright notice(s) and proprietary legend(s) of TI and its licensors as they appear in the Licensed Materials.  TI reserves all rights not specifically granted under this Agreement.
 *
 *	b.	Certain Licensed Materials may be based on industry recognized standards or software programs published by industry recognized standards bodies and certain third parties may claim to own patents, copyrights, and other intellectual property rights that cover implementation of those standards.  You acknowledge and agree that this Agreement does not convey a license to any such third party patents, copyrights, and other intellectual property rights and that you are solely responsible for any patent, copyright, or other intellectual property right claim that relates to your use or distribution of the Licensed Materials or your use or distribution of your products that include or incorporate the Licensed Materials.  Moreover, you acknowledge that you are responsible for any fees or royalties that may be payable to any third party based on such third party's interests in the Licensed Materials or any intellectual property rights that cover implementation of any industry recognized standard, any software program published by any industry recognized standards bodies or any other proprietary technology.
 *
 *4.	Confidential Information.  You acknowledge and agree that the Licensed Materials contain trade secrets and other confidential information of TI and its licensors.  You agree to use the Licensed Materials solely within the scope of the licenses set forth herein, to maintain the Licensed Materials in strict confidence, to use at least the same procedures and degree of care that you use to prevent disclosure of your own confidential information of like importance but in no instance less than reasonable care, and to prevent disclosure of the Licensed Materials to any third party, except as may be necessary and required in connection with your rights and obligations hereunder; provided, however, that you may not provide the Licensed Materials to any business organization or group within your company or to customers or contractors that design or manufacture semiconductors unless TI gives written consent.  You agree to obtain executed confidentiality agreements with your employees and contractors having access to the Licensed Materials and to diligently take steps to enforce such agreements in this respect.  TI may disclose your contact information to TI's licensors.
 *
 *5.	Warranties and Limitations.  THE LICENSED MATERIALS ARE PROVIDED "AS IS".  FURTHERMORE, YOU ACKNOWLEDGE AND AGREE THAT THE LICENSED MATERIALS HAVE NOT BEEN TESTED OR CERTIFIED BY ANY GOVERNMENT AGENCY OR INDUSTRY REGULATORY ORGANIZATION OR ANY OTHER THIRD PARTY ORGANIZATION.  YOU AGREE THAT PRIOR TO USING, INCORPORATING OR DISTRIBUTING THE LICENSED MATERIALS IN OR WITH ANY COMMERCIAL PRODUCT THAT YOU WILL THOROUGHLY TEST THE PRODUCT AND THE FUNCTIONALITY OF THE LICENSED MATERIALS IN OR WITH THAT PRODUCT AND BE SOLELY RESPONSIBLE FOR ANY PROBLEMS OR FAILURES.
 *
 *TI AND ITS LICENSORS MAKE NO WARRANTY OR REPRESENTATION, EITHER EXPRESS, IMPLIED OR STATUTORY, REGARDING THE LICENSED MATERIALS, INCLUDING BUT NOT LIMITED TO ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT OF ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADE SECRETS OR OTHER INTELLECTUAL PROPERTY RIGHTS.  YOU AGREE TO USE YOUR INDEPENDENT JUDGMENT IN DEVELOPING YOUR PRODUCTS.  NOTHING CONTAINED IN THIS AGREEMENT WILL BE CONSTRUED AS A WARRANTY OR REPRESENTATION BY TI TO MAINTAIN PRODUCTION OF ANY TI SEMICONDUCTOR DEVICE OR OTHER HARDWARE OR SOFTWARE WITH WHICH THE LICENSED MATERIALS MAY BE USED.  
 *
 *IN NO EVENT SHALL TI OR ITS LICENSORS, BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, HOWEVER CAUSED, ON ANY THEORY OF LIABILITY, IN CONNECTION WITH OR ARISING OUT OF THIS AGREEMENT OR THE USE OF THE LICENSED MATERIALS REGARDLESS OF WHETHER TI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.  EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF REMOVAL OR REINSTALLATION, OUTSIDE COMPUTER TIME, LABOR COSTS, LOSS OF DATA, LOSS OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF USE OR INTERRUPTION OF BUSINESS.  IN NO EVENT WILL TI'S OR ITS LICENSORS' AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF YOUR USE OF THE LICENSED MATERIALS EXCEED FIVE HUNDRED U.S. DOLLARS (US$500).
 *
 *	Because some jurisdictions do not allow the exclusion or limitation of incidental or consequential damages or limitation on how long an implied warranty lasts, the above limitations or exclusions may not apply to you.
 *
 *6.	Indemnification Disclaimer.  YOU ACKNOWLEDGE AND AGREE THAT TI SHALL NOT BE LIABLE FOR AND SHALL NOT DEFEND OR INDEMNIFY YOU AGAINST ANY THIRD PARTY INFRINGEMENT CLAIM THAT RELATES TO OR IS BASED ON YOUR MANUFACTURE, USE, OR DISTRIBUTION OF THE LICENSED MATERIALS OR YOUR MANUFACTURE, USE, OFFER FOR SALE, SALE, IMPORTATION OR DISTRIBUTION OF YOUR PRODUCTS THAT INCLUDE OR INCORPORATE THE LICENSED MATERIALS.
 *
 *7.	No Technical Support.  TI and its licensors are under no obligation to install, maintain or support the Licensed Materials.  
 *
 *8.	Notices.  All notices to TI hereunder shall be delivered to Texas Instruments Incorporated, 12500 TI Boulevard, Mail Station 8638, Dallas, Texas 75243, Attention: Contracts Manager - Embedded Processing, with a copy to Texas Instruments Incorporated, 13588 N. Central Expressway, Mail Station 3999, Dallas, Texas 75243, Attention: Law Department - Embedded Processing.  All notices shall be deemed served when received by TI. 
 *
 *9.	Export Control.  The Licensed Materials are subject to export control under the U.S. Commerce Department's Export Administration Regulations ("EAR").  Unless prior authorization is obtained from the U.S. Commerce Department, neither you nor your subsidiaries shall export, re-export, or release, directly or indirectly (including, without limitation, by permitting the Licensed Materials to be downloaded), any technology, software, or software source code, received from TI, or export, directly or indirectly, any direct product of such technology, software, or software source code, to any person, destination or country to which the export, re-export, or release of the technology, software, or software source code, or direct product is prohibited by the EAR.  You represent and warrant that you (i) are not located in, or under the control of, a national or resident of Cuba, Iran, North Korea, Sudan and Syria or any other country subject to a U.S. goods embargo; (ii) are not on the U.S. Treasury Department's List of Specially Designated Nationals or the U.S. Commerce Department's Denied Persons List or Entity List; and (iii) will not use the Licensed Materials or transfer the Licensed Materials for use in any military, nuclear, chemical or biological weapons, or missile technology end-uses.  Any software export classification made by TI shall not be construed as a representation or warranty regarding the proper export classification for such software or whether an export license or other documentation is required for the exportation of such software.
 *
 *10.	Governing Law and Severability; Waiver.  This Agreement will be governed by and interpreted in accordance with the laws of the State of Texas, without reference to conflict of laws principles.  If for any reason a court of competent jurisdiction finds any provision of the Agreement to be unenforceable, that provision will be enforced to the maximum extent possible to effectuate the intent of the parties, and the remainder of the Agreement shall continue in full force and effect.  This Agreement shall not be governed by the United Nations Convention on Contracts for the International Sale of Goods, or by the Uniform Computer Information Transactions Act (UCITA).  The parties agree that non-exclusive jurisdiction for any dispute arising out of or relating to this Agreement lies within the courts located in the State of Texas.  Notwithstanding the foregoing, any judgment may be enforced in any United States or foreign court, and either party may seek injunctive relief in any United States or foreign court.  Failure by TI to enforce any provision of this Agreement shall not be deemed a waiver of future enforcement of that or any other provision in this Agreement or any other agreement that may be in place between the parties.
 *
 *11.	PRC Provisions.  If you are located in the People's Republic of China ("PRC") or if the Licensed Materials will be sent to the PRC, the following provisions shall apply:  
 *
 *	a.	Registration Requirements.  You shall be solely responsible for performing all acts and obtaining all approvals that may be required in connection with this Agreement by the government of the PRC, including but not limited to registering pursuant to, and otherwise complying with, the PRC Measures on the Administration of Software Products, Management Regulations on Technology Import-Export, and Technology Import and Export Contract Registration Management Rules.  Upon receipt of such approvals from the government authorities, you shall forward evidence of all such approvals to TI for its records.  In the event that you fail to obtain any such approval or registration, you shall be solely responsible for any and all losses, damages or costs resulting therefrom, and shall indemnify TI for all such losses, damages or costs.
 *
 *b.	Governing Language.  This Agreement is written and executed in the English language and shall be authoritative and controlling, whether or not translated into a language other than English to comply with law or for reference purposes.  If a translation of this Agreement is required for any purpose, including but not limited to registration of the Agreement pursuant to any governmental laws, regulations or rules, you shall be solely responsible for creating such translation.  
 *
 *12.	Contingencies.	TI shall not be in breach of this Agreement and shall not be liable for any non-performance or delay in performance if such non-performance or delay is due to a force majeure event or other circumstances beyond TI's reasonable control.
 *
 *13.		Entire Agreement.  This is the entire agreement between you and TI and this Agreement supersedes any prior agreement between the parties related to the subject matter of this Agreement.  Notwithstanding the foregoing, any signed and effective software license agreement relating to the subject matter hereof and stating expressly that such agreement shall control regardless of any subsequent click-wrap, shrink-wrap or web-wrap, shall supersede the terms of this Agreement.  No amendment or modification of this Agreement will be effective unless in writing and signed by a duly authorized representative of TI.  You hereby warrant and represent that you have obtained all authorizations and other applicable consents required empowering you to enter into this Agreement.
 *
 *
 *
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2xxx Demo - Programmable Frequency Locked Loop (0 - 16MHz)
//
//  Description:Programmable clock source using FLL to stabilize the DCO.
//  Commands can be sent to the device over a 4800 baud UART or 4-wire SPI
//  interface to achieve output frequencies between 0 and 16MHZ. The MSP430 can
//  source the FLL reference from either the internal reference oscillator(REFO)
//  or a 32768 Hz external crystal.
//
//           MSP430FR2xxx
//         ---------------
//        |      (P2.7)XIN|--
//     /|\|               |  ~32768Hz
//      | |     (P2.6)XOUT|--
//      --|RST            |
//        |           P1.4|<-- SPI Chip Select (CS)
//        |           P1.5|<-- SPI Clock (CLK)
//        |           P1.6|<-- RXD/MOSI
//        |           P1.7|--> TXD/MISO
//        |               |
//        |           P1.2|--> INT
//        |               |
//        |           P1.1|--> 32768 Hz (Fixed)
//        |           P1.0|--> Frequency Output
//
//   Caleb Overbay
//   Texas Instruments Inc.
//   Aug 2017
//   Built with IAR Embedded Workbench v7.10 & Code Composer Studio v7.2
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>
#include <stdbool.h>

/* Constant Definitions */
#define USE_LFXT           // USE_LFXT or USE_REFO
#define UART               // Communication interface (SPI or UART)

// Status register bitfield
#define SUCCESS            (BIT0) // Last command was executed successfully
#define FAIL               (BIT1) // Last command failed to execute properly
#define PROCESSING         (BIT2) // Last command is currently processing
#define LFXT_FAULT         (BIT3) // LFXT fault occurred/using REFO
#define FLL_UNLOCK         (BIT4) // FLL is currently unlocked
#define DCO_RANGE_ERROR    (BIT5) // The DCO has been out of range since the
                                  // status register was last read
#define INVALID_COMMAND    (BIT6) // There was an invalid command since the
                                  // status register was last read

// Valid user commands
#define COMMAND_APPLY_CS_SETTINGS     (0x00)
#define COMMAND_SET_DCO_RANGE         (0x01)
#define COMMAND_SET_FLL_N             (0x02)
#define COMMAND_SET_OUT_DIV           (0x03)
#define COMMAND_GET_STATUS            (0x04)

// Communication Protocol States
#define CI_STATE_COMMAND    (0x00)
#define CI_STATE_DATA0      (0x01)
#define CI_STATE_DATA1      (0x02)

#define DCOTAP_MID_RANGE    (0x100)  // Defines the ideal DCO tap value (256)

/* Macro Definitions */
#define SET_ALERT()    (P1OUT |=  BIT2)
#define CLEAR_ALERT()  (P1OUT &= ~BIT2)

// Union to store received data
typedef union
{
    struct
    {
        uint8_t lowerByte;
        uint8_t upperByte;
    }bytes;
    uint16_t word;
}CI_dataUnion;

/* Global Variable Declarations */
#if defined (__TI_COMPILER_VERSION__)
static uint8_t CS_lockAttempts;            // Tracks number of FLL lock attempts
static volatile uint8_t CI_state;          // Current state of comm interface
static volatile uint8_t CI_command;        // Command rx'd from comm interface
static volatile CI_dataUnion CI_data;      // Data rx'd from comm interface
static volatile uint16_t CS_tempFLLN;      // Stores the user input FLLN
static volatile uint16_t CS_tempDCORange;  // Stores the user input DCORANGE
static volatile uint8_t statusRegister;    // Tracks the status of operation

// Global variables stored in non-volatile FRAM
#pragma PERSISTENT(CS_validDCORange)
volatile uint16_t CS_validDCORange = DCORSEL_0;  // Stores the DCO range in FRAM
#pragma PERSISTENT(CS_validFLLN)
volatile uint16_t CS_validFLLN = 0x001E;         // Stores the FLLN in FRAM
#pragma PERSISTENT(CS_outputDiv)
volatile uint16_t CS_outputDiv = VLOAUTOOFF;// Stores the output divider in FRAM

#elif defined (__IAR_SYSTEMS_ICC__)
__no_init static uint8_t CS_lockAttempts;
__no_init static volatile uint8_t CI_state;
__no_init static volatile uint8_t CI_command;
__no_init static volatile CI_dataUnion CI_data;
__no_init static volatile uint16_t CS_tempFLLN;
__no_init static volatile uint16_t CS_tempDCORange;
__no_init static volatile uint8_t statusRegister;

// Global variables stored in non-volatile FRAM
__persistent volatile uint16_t CS_validDCORange = DCORSEL_0;
__persistent volatile uint16_t CS_validFLLN = 0x001E;
__persistent volatile uint16_t CS_outputDiv = VLOAUTOOFF;
#endif

/* Local Function Prototypes */
static inline void TB0_delay();
static inline void eUSCI_init();
static inline void CS_setupFLL();
static inline void Command_process();
static inline void CS_revertFLLSettings();
static inline void CS_calculateSoftwareTrim();
static inline void CS_updateFLLSettings(uint16_t reg0, uint16_t reg1);

/**
 * main.c
 */
void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;    // Stop WDT
    FRCTL0 = FRCTLPW | NWAITS_1; // Enable wait states

    SYSCFG0 = FRWPPW;            // Enable FRAM write access
    CI_state = CI_STATE_COMMAND; // Set communication state to receive a command

    /*
     * These settings will cause the device to restore
     * the last locked frequency
     */
    CI_command = COMMAND_APPLY_CS_SETTINGS;
    statusRegister = (PROCESSING | LFXT_FAULT | FLL_UNLOCK);

    CS_tempDCORange = CS_validDCORange; // Update to a valid DCO Range
    CS_tempFLLN = CS_validFLLN;         // Update to a valid FLLN
    CS_lockAttempts = 0;                // Number of FLL lock attempts, max 4

    // Set all GPIO to output low for power savings
    PAOUT = 0x0000;
    PADIR = 0xFFFF;

    P1SEL1 |= (BIT1 | BIT0);   // P1.0 = SMCLK, P1.1 = ACLK = 32768

    eUSCI_init();     // Initialize UART or SPI communication interface

#ifdef USE_LFXT       //Use XT1 as FLL reference clock

    P2SEL1 = BIT6 | BIT7;    //Set 2.6 and P2.7 as XT1 pins

    /* Setup TimerB for timeout detection */
    TB0CCR0 = 0xFFFE;                          // 2 second timeout
    TB0CCTL0 &= ~CCIFG;                        // Clear CCR0 interrupt flag
    TB0CTL = (TBSSEL_1 | MC_1 | TBCLR);        // SRC = ACLK/2, Up modeS

    // Loop until LFXT is stable or timeout after 2 seconds
    do
    {
        CSCTL7 &= ~(XT1OFFG | DCOFFG);     // Clear XT1 and DCO fault flag
        SFRIFG1 &= ~OFIFG;                 // Clear oscillator fault flag
    }while ((SFRIFG1 & OFIFG) && (!(TB0CCTL0 & CCIFG)));

    TB0CTL = MC_0;        // Stop the timer

    // Check for timeout
    if(TB0CCTL0 & CCIFG)
    {
        P2SEL1 = 0x00;    // Disable LFXT pins
        SET_ALERT();      // Alert host that LFXT failed to oscillate
    }
    else
    {
        CSCTL4 = SELA__XT1CLK;         // Source ACLK from XT1 (32768 Hz)
        statusRegister &= ~LFXT_FAULT; // Clear LFXT fault in status register
    }
#endif

    PM5CTL0 &= ~LOCKLPM5;    // Disable the GPIO power-on default high-impedance
                             // mode to activate configured port settings

    __bis_SR_register(GIE);  // Enable global interrupts

    // Loop forever, waking when a new command is received or FLL unlocks
    while(1)
    {
        Command_process();                 // Process command

        // Only enter LPM0 if FLL is locked or FLL has attempted to lock 4 times
        if(!(statusRegister & FLL_UNLOCK))
        {
            __bis_SR_register(LPM0_bits);  // Enter LPM0, wake on rx'd command
        }
        else if(CS_lockAttempts > 4)
        {
            // Alert host that FLL is unlocked and failed to correct
            statusRegister &= ~PROCESSING;
            statusRegister |= FAIL + DCO_RANGE_ERROR;
            SET_ALERT();
            CS_lockAttempts = 0;
            __bis_SR_register(LPM0_bits);  // Enter LPM0, wake on rx'd command
        }
    }
}

/**
* Configure UART (see UG)
* 4800 baud at BRCLK = 32768 Hz
* UCOS16 = 0
* UCBRx = 6
* UCBRFx = 0
* UCBRSx = 0xEE
*
* OR
*
* Configure SPI
* 4-pin slave mode
* Clock Polarity: The inactive state is high
* Clock Phase: Data changed on first UCLK edge and captured on second
* Chip Select: Active low
 */
static inline void eUSCI_init()
{
#ifdef SPI
// SPI communication
    P1SEL0 |= BIT4 | BIT5 | BIT6 | BIT7;  // Initialize for USCIA0 SPI operation

    UCA0CTLW0 = UCSWRST;                  // Hold SPI in reset mode
    UCA0CTLW0 |= UCSYNC|UCCKPL|UCMSB|UCMODE_2|UCSTEM;
    UCA0CTLW0 &= ~UCSWRST;                //Release SPI from reset

    UCA0IE = UCRXIE;   // Enable receive interrupt
#endif

#ifdef UART
//UART Communication         // Initialize for USCIA0 UART operation
    P1SEL0 |= (BIT6 | BIT7);

    // Configure UART_A0
    UCA0CTLW0 = UCSWRST;    // Hold UART module in reset mode
    UCA0BRW = 6;            // 4800 baud
    UCA0MCTLW = 0xEE00;     // 32768/4800 - INT(32768/4800)=0.83
                            // UCBRSx value = 0xEE (See UG)
    UCA0CTLW0 = UCSSEL_1;   // release from reset and set ACLK=32768 as UCBRCLK
    UCA0IE = UCRXIE;        // Enable receive interrupt
#endif
}

/**
 * Routine to apply the requested clock system settings
 */
static inline void CS_setupFLL()
{
    SFRIE1 &= ~OFIE;            // Disable oscillator fault interrupt

    __bis_SR_register(SCG0);    // Disable FLL
#ifdef  USE_LFXT
    CSCTL3 = SELREF__XT1CLK;    // Set FLL reference source to LFXT
#else
    CSCTL3 = SELREF__REFOCLK;   // Set FLL reference source to REFO
#endif
    CSCTL0 = 0x00;              // Clear DCO and MOD bits

    // Set DCO range, enable software trim
    CSCTL1 = CS_tempDCORange + DISMOD + DCOFTRIMEN_1 + DCOFTRIM0 + DCOFTRIM1;
    CSCTL2 = CS_tempFLLN;       // Set the FLLN bits
    CSCTL5 = CS_outputDiv;      // Set the MCLK divider
    __delay_cycles(3);          // Delay for settings to take hold
    __bic_SR_register(SCG0);    // Enable FLL

    CS_calculateSoftwareTrim(); // Software trim to attempt FLL
                                // Modifies the statusRegister

    // If the FLL locked, setup FLL unlock detection
    if(!(statusRegister & FLL_UNLOCK))
    {
        CSCTL7 &= ~(FLLUNLOCKHIS| XT1OFFG | DCOFFG); // Clear the FLL unlock history
        SFRIFG1 &= ~OFIFG;       // Clear oscillator fault flag
        CSCTL7 |= FLLWARNEN;     // Enable FLL unlock detection
        SFRIE1 |= OFIE;          // Enable osc fault interrupts
    }
}

/**
 * Routine to process commands from communication interface (CI)
 */
static inline void Command_process()
{
    // Switch based on the command received, invalid commands are handled in ISR
    switch(CI_command)
    {
        case COMMAND_APPLY_CS_SETTINGS:  // Apply the requested settings
            CS_setupFLL();   // Modifies the statusRegister
            break;
        case COMMAND_SET_DCO_RANGE:  // Set DCO range value
            CS_tempDCORange = CI_data.word;
            statusRegister &= ~PROCESSING;
            statusRegister |= SUCCESS;
            break;
        case COMMAND_SET_FLL_N:  // Set FLLN value
            CS_tempFLLN = CI_data.word;
            statusRegister &= ~PROCESSING;
            statusRegister |= SUCCESS;
            break;
        case COMMAND_SET_OUT_DIV:  // Set FLLN value
            //CS_outputDiv = VLOAUTOOFF | (0x0007 & CI_data[0]);
            CS_outputDiv = VLOAUTOOFF | CI_data.bytes.lowerByte;
            CSCTL5 = CS_outputDiv;
            statusRegister &= ~PROCESSING;
            statusRegister |= SUCCESS;
            break;
    }
}

/**
 * Calculates the best software trim to lock the FLL. See User's Guide for a
 * step by step breakdown of this function.
 *
 * User's Guide (3.2.11.2 DCO Software Trim): http://www.ti.com/lit/pdf/slau445
 *
 * If the DCORANGE selection is invalid for the requested frequency, this
 * function will fail to lock the FLL. The function then starts the process of
 * reverting back to the last known lock-able FLL settings
 */
static inline void CS_calculateSoftwareTrim()
{
    bool bestTrimFound = false;       // Signals when best trim is found
    uint8_t untestedTrims = 13;       // Number of untested trim settings
    uint16_t prevDCOTap  = 0xFFFF;    // Stores the previous DCO tap setting
    uint16_t newDCOTap   = 0xFFFF;    // Stores the new DCO tap setting
    uint16_t newDCODelta = 0xFFFF;    // Abs(currentDCOTap - 256)
    uint16_t minDCODelta = 0xFFFF;    // min(newDCODelta)
    uint16_t bestCSCTL0  = 0x0000;    // Stores the best CSCTL0 setting
    uint16_t bestCSCTL1  = 0x0000;    // Stores the best CSCTL1 setting
    uint16_t copyCSCTL0  = 0x0000;    // Stores a copy of CSCTL0
    uint16_t copyCSCTL1  = 0x0000;    // Stores a copy of CSCTL1
    uint16_t dcoFreqTrim = 0x0003;    // The current DCO frequency trim setting

    CS_lockAttempts++;                // Increase the number of lock attempts

    // Loop until FLL can lock, or all trim settings have been tested
    while(!bestTrimFound && untestedTrims)
    {
        CSCTL0 = DCOTAP_MID_RANGE;    // DCO Tap = 256 (mid-range)
        CSCTL7 &= ~DCOFFG;            // Clear DCO fault flag

        TB0_delay();                  // Delay until FLLUNLOCK is stable

        // Poll until FLL is locked or DCO fault occurs
        while((CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1)) && (!(CSCTL7 & DCOFFG)));

        copyCSCTL0 = CSCTL0;                    // Read CSCTL0
        copyCSCTL1 = CSCTL1;                    // Read CSCTL1

        prevDCOTap = newDCOTap;                 // Record prev DCO tap value
        newDCOTap = copyCSCTL0 & 0x01ff;        // Extract the new DCO tap value
        dcoFreqTrim = (copyCSCTL1 & 0x70)>>4;   // Extract DCO freq trim value


        // Check if DCOTAP is greater than or less than mid-range
        if(newDCOTap < DCOTAP_MID_RANGE) // DCOTAP < 256
        {
            // Record difference from mid-range
            newDCODelta = DCOTAP_MID_RANGE - newDCOTap;

            // Check if DCOTAP crossed mid-range since last test
            if((prevDCOTap != 0xffff) && (prevDCOTap >= DCOTAP_MID_RANGE))
                bestTrimFound = true;    // Best frequency trim found
            else
            {
                // Lower frequency trim setting and try again
                dcoFreqTrim--;
            }
        }
        else // DCOTAP >= 256
        {
            // Record difference from mid-range
            newDCODelta = newDCOTap - DCOTAP_MID_RANGE;

            // Check if DCOTAP crossed mid-range since last test
            if(prevDCOTap < DCOTAP_MID_RANGE)
                bestTrimFound = true;    // Best frequency trim found
            else
            {
                // Increase frequency trim setting and test again
                dcoFreqTrim++;
            }
        }

        // If the best frequency trim hasn't been found, test again
        if(!bestTrimFound)
        {
            CSCTL1 = (copyCSCTL1 & (~DCOFTRIM)) | (dcoFreqTrim<<4);
        }

        // Record DCOTAP closest to 256 (mid-range)
        if(newDCODelta < minDCODelta)
        {
            bestCSCTL0 = copyCSCTL0;
            bestCSCTL1 = copyCSCTL1;
            minDCODelta = newDCODelta;
        }

        untestedTrims--;  // Reduce remaining trims left to test
    } // End of while

    // If there are untested trim settings, the best one has already been found
    if(untestedTrims)
    {
        // Lock FLL, Update DCO range and FLLN
        CS_updateFLLSettings(bestCSCTL0, bestCSCTL1);
    }
    else //Unable to find best trim because DCO range is invalid
    {
        CS_revertFLLSettings();  // Revert to last known lock-able FLL settings
    }
}

/**
 * Helper functions for CS_calculateSoftwareTrim
 *
 * When the best frequency trim settings have been found:
 *   1. Update CSCTL0 and CSCTL1 with best tap and trim settings
 *   2. Lock the FLL
 *   3. Update DCO Range and FLLN
 *   4. Clear the number of lock attempts
 *   5. Check if this is a successful lock after an unsuccessful user command
 *   6. Clear the FLL_UNLOCK and processing bits in statusRegister
 */
static inline void CS_updateFLLSettings(uint16_t reg0, uint16_t reg1)
{
    CSCTL0 = reg0;   // Reload best DCOTAP
    CSCTL1 = reg1;   // Reload best DCOFTRIM

    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1)); // Poll until FLL is locked
    CS_validDCORange = CS_tempDCORange;   // Store the newest valid DCO range
    CS_validFLLN = CS_tempFLLN;           // Store the newest valid FLLN
    CS_lockAttempts = 0;                  // Clear number of FLL lock attempts

    // If user command didn't fail on first lock attempt, command was successful
    if((statusRegister & PROCESSING) && !(statusRegister & FAIL))
    {
        statusRegister |= SUCCESS;
    }

    // Device is done processing request and FLL is locked
    statusRegister &= ~(PROCESSING + FLL_UNLOCK);
}

/**
 * Helper functions for CS_calculateSoftwareTrim
 *
 * When the best software trim setting cannot be found:
 *   1. Revert the DCO range and FLLN to known lock-able values
 *   2. Set FLL_UNLOCK in statusRegister
 *   3. Check if the unlock was caused by user trying to set frequency outside
 *      of valid DCO range
 *          a. If so, set FAIL and DCO_RANGE_ERROR in statusRegister
 *          b. Alert the host by setting P1.2 high
 */
static inline void CS_revertFLLSettings()
{
    CS_tempDCORange = CS_validDCORange;
    CS_tempFLLN = CS_validFLLN;
    statusRegister |= FLL_UNLOCK;
    if(statusRegister & PROCESSING)
    { // Failed while processing a command
        statusRegister |= FAIL + DCO_RANGE_ERROR;
        SET_ALERT();
    }
}

/**
 * Helper functions for CS_calculateSoftwareTrim
 *
 * Set up TimerB0 to delay for 24 FLL ref clock cycles: 24/32768 = 0.733ms
 */
static inline void TB0_delay()
{
    TB0CCR0 = 24;           // Wait FLL lock status (FLLUNLOCK) to be stable
    TB0CCTL0 &= ~CCIFG;     // Min wait time is 24 cycles of FLL ref clock
    TB0CTL = TBSSEL_1 + MC_1 + TBCLR;  // SRC = ACLK, Up mode
    while(!(TB0CCTL0 & CCIFG));        // Poll until timer counts to CCR0
    TB0CTL = MC_0;                     // Stop the timer
}

/**
 * USCI_A0 SPI and UART interrupt service routine
 */
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
#else
#error "Compiler not supported!"
#endif
{
    UCA0IFG = 0x00; // Clear the RX and TX interrupt flags

    // Only accept new data if a command if not currently processing
    if(!(statusRegister & PROCESSING))
    {
        switch(CI_state)   // Switch on what data is expected
        {
            case CI_STATE_COMMAND:   // Expecting data to be a new command

                CI_command = UCA0RXBUF;  // Read the received data

                //  Check if received data is a valid command
                if(CI_command == COMMAND_APPLY_CS_SETTINGS)
                { // Apply settings is a one byte command

                    // Clear FAIL and SUCCESS bits while processing
                    statusRegister &= ~(SUCCESS + FAIL);
                    statusRegister |= PROCESSING;
                    CI_state = CI_STATE_COMMAND;

                    __bic_SR_register_on_exit(LPM0_bits);  // Exit LPM0
                }
                else if(CI_command == COMMAND_GET_STATUS)
                {// Get status is a one byte command
                    UCA0TXBUF = statusRegister;   // Respond with statusRegister

                    // Clear range error and invalid command indicators
                    statusRegister &= ~(DCO_RANGE_ERROR | INVALID_COMMAND);
                    CLEAR_ALERT();  //De-assert host alert pin
                }
                else if(CI_command < COMMAND_GET_STATUS)
                {// Received first byte of command
                    CI_state++;
                }
                else
                {//Invalid command
                    statusRegister |=  INVALID_COMMAND;
                }
                break;
            case CI_STATE_DATA0:          // Expecting 1st data byte of command
                CI_data.bytes.lowerByte = UCA0RXBUF;   // Read the received data
                CI_state++;
                break;
            case CI_STATE_DATA1:          // Expecting 2nd data byte of command
                CI_data.bytes.upperByte = UCA0RXBUF;  // Read the received data

                // Clear FAIL and SUCCESS bits while processing
                statusRegister &= ~(SUCCESS + FAIL);
                statusRegister |= PROCESSING;
                CI_state = CI_STATE_COMMAND;

                __bic_SR_register_on_exit(LPM0_bits);   // Exit LPM0
                break;
        }
    }
    else  // Processing command, respond with status register
    {
        UCA0TXBUF = statusRegister;
    }
}

/**
 * User NMI ISR to catch FLL unlock and LFXT fault events
 */
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=UNMI_VECTOR
__interrupt void UNMI_ISR(void)
#else
#error Compiler not supported!
#endif
{
    if(CSCTL7 & XT1OFFG)  // LFXT fault, switch to REFO
    {
        statusRegister |= LFXT_FAULT;   // Signal that LFXT fault occurred
        P2SEL1 = 0x00;                  // Disable XT1 pins
        CSCTL4 = SELA__REFOCLK;         // Switch ACLK to REFO
        CSCTL7 &= ~XT1OFFG;             // Clear fault flag
        SET_ALERT();                    // Alert host that a fault occurred
    }
    else if(CSCTL7 & (FLLUNLOCKHIS0 | FLLUNLOCKHIS1)) // FLL unlock condition
    {
        // Exit LPM0 and force FLL to re-adjust trim settings
        CI_command = COMMAND_APPLY_CS_SETTINGS;
        statusRegister |= FLL_UNLOCK;         // Signal that the FLL is unlocked
        SFRIE1 &= ~OFIE;                      // Disable osc fault interrupt
        __bic_SR_register_on_exit(LPM0_bits); // Exit LPM0
    }

    SFRIFG1 &= ~OFIFG;  // Clear the oscillator fault interrupt flag
}


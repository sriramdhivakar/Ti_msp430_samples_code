/* --COPYRIGHT--,BSD-3-Clause
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 ANALOG to PWM Demo
//
//  Description: Using eCOMP build in 6-bit DAC and comparator to measure the analog voltage
//  then indicate the result by output different frequency of PWM waveforms(50% duty). With a button trigger ISR on
//  GPIO to start the measurement.
//
//  XT1 is considered to be absent in this example.
//  ACLK = default REFO ~32768Hz, MCLK = SMCLK = default DCODIV ~1.048MHz.
//
//                MSP430FR2000
//             ------------------
//         /|\|                  |
//          | |                  |
//          --|RST        P1.1/C1|<--Vinput
//            |                  |
//            |        P2.0/TB0.1|----> CCR1 - PWM,
//            |                  |
//      /|\   |                  |
//       --o--|P1.3              |
//      \|/   |                  |
//
//  Description: After press mechanical button which connnected to P1.3 will trigger GPIO ISR then
//    Use eCOMP and internal VREF(1.5V) to determine if input 'Vinput'
//    is high or low.  When Vinput exceeds or below VREF * n/64, adjust the n(buffer data
//    of DAC) and compare again until the output of DAC is closest to Vinput.
//    The final output of DAC is the result of the measurement and indicated with different
//    PWM output by TimerB0 (with 50% duty).
//
//   KC Xu
//   Texas Instruments Inc.
//   September 2017
//   Built with IAR Embedded Workbench v7.1 & Code Composer Studio v7.2
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>

/**
 * main.c
 */
void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer

    uint16_t PWMData = 0;                   // Use to setting TB0CCR0 for PWM
    uint16_t DACData = 0;                   // Use to setting CPDACBUF
    uint8_t  DACDataAdj = 0;                 // Use to adjust CPDACBUF
    uint16_t eCompResult = 0;               // Result comparator

    // Configure Comparator input & output
    P1SEL0 |= BIT1;                           // Select eCOMP input function on P1.1/C1
    P1SEL1 |= BIT1;

    P1OUT |= BIT3;                          // Configure P1.3 as pulled-up
    P1REN |= BIT3;                          // P1.3 pull-up register enable
    P1IES |= BIT3;                          // P1.3 Hi/Low edge
    P1IE  |= BIT3;                          // P1.3 interrupt enabled
    P1IFG &= ~BIT3;                         // P1.3 IFG cleared

    // Configure P2.0 for CCR1
    PASEL0 |= BIT8;
    PADIR |= BIT8;         // TB0.0
    PAOUT = 0;

    PM5CTL0 &= ~LOCKLPM5;                     // Disable the GPIO power-on default high-impedance mode
                                              // to activate previously configured port settings
    // Configure reference
    PMMCTL0_H = PMMPW_H;                      // Unlock the PMM registers
    PMMCTL2 |= INTREFEN;                      // Enable internal reference
    while(!(PMMCTL2 & REFGENRDY));            // Poll till internal reference settles

    // Setup eCOMP
    CPCTL0 = CPPSEL0 | CPNSEL1 | CPNSEL2 |CPPEN | CPNEN;  // Select C1 as input for V+ terminal
                                                          // Select DAC as input for V- terminal
                                                          // Enable eCOMP input
    CPDACCTL |= CPDACREFS | CPDACEN;          // Select on-chip VREF and enable DAC

    TB0CCR0 = 0;                                // PWM Period (off)
    TB0CCR1 = 0;
    TB0CCTL1 = OUTMOD_7;                        // CCR1 reset/set
    TB0CTL = TBSSEL__SMCLK | MC__UP | TBCLR;    // SMCLK, up mode, clear TBR

    SYSCFG2 |= TB0TRGSEL;                       // ECOMP will not affect TimerB if TB0TRGSEL is set

    while(1)
    {
        DACData = 0x0020;  //use to setting CPDACBUF, 0x20 = 32/64
        DACDataAdj = DACData;
        eCompResult = 0;
        __bis_SR_register(LPM0_bits | GIE); // Enter LPM3 w/interrupt
        __no_operation();                   // For debug
       do
        {
            CPDACDATA = DACData;             // CPDACBUF1=On-chip VREF * DACData/64
            CPCTL1 |= CPEN;                  // Turn on eCOMP, in high power mode
            __delay_cycles(10);              // Delay added here to make sure the data of CPOUT has been update

            eCompResult = CPCTL1;
            eCompResult &= CPOUT;            // Read out the result of comparator

            DACDataAdj = DACDataAdj >> 1;    // Use to adjust CPDACBUF
            if(DACDataAdj == 0)
            {
                __no_operation();            // Run here means the final value of DACData has been found then break the loop
                break;
            }
            if(eCompResult)   //C1 > DAC
            {
                DACData = DACData + DACDataAdj;   //increase DAC setting
            }
            else              //C1 < DAC
            {
                DACData = DACData - DACDataAdj;   //decrease DAC setting
            }
        }while(1);
        PWMData = CPDACDATA;                      //Read out DACData;
        TB0CCR0 = PWMData << 7;                   //Set the PWM frequency as 1/TB0CCR0
        TB0CCR1 = PWMData << 6;                   //Set 50% duty.
    }
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    P1IFG &= ~BIT3;                         // Clear P1.3 IFG
    __bic_SR_register_on_exit(LPM0_bits);   // Exit LPM3
}

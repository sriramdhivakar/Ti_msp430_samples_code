/* --COPYRIGHT--,BSD_EX
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *******************************************************************************
 *
 *                       MSP430 CODE EXAMPLE DISCLAIMER
 *
 * MSP430 code examples are self-contained low-level programs that typically
 * demonstrate a single peripheral function or device feature in a highly
 * concise manner. For this the code may rely on the device's power-on default
 * register values and settings such as the clock configuration and care must
 * be taken when combining code from several examples to avoid potential side
 * effects. Also see www.ti.com/grace for a GUI- and www.ti.com/msp430ware
 * for an API functional library-approach to peripheral configuration.
 *
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Demo - SPI-to-UART Bridge
//
//  Description: This example enables serial communication between a UART device
//  and a SPI device. The hardware SPI interface utilizes the
//  eUSCI_A module, and the software (SW) UART interface utilizes Timer_B.
//  Connect the SPI device to the SPI interface
//  (P1.5, P1.6 and P1.7), and connect the UART device to the
//  SW UART interface (P2.0 and P2.1). This example supports half-duplex
//  UART communication only, eight data bits with least significant bit first,
//  no parity bit, and one stop bit. After initializing everything, the CPU
//  waits in LPM0 to save power until a SPI or UART receive interrupt occurs.
// Then, the CPU exits LPM0, reads the SPI or UART data, transmits the data on
//  the other interface, and returns to LMP0.
//  ACLK = default REFO ~32768Hz, MCLK = SMCLK = 16MHz
//
//                               MSP430FR2000
//                           -------------------
//                       /|\|                   |
//                        | |                   |
//                        --|RST                |
//                          |                   |
//               SPI CLK <--|P1.5/UCA0CLK       |
//                          |                   |
//              SPI MISO -->|P1.6/UCA0SOMI  P2.0|--> SW UART TX Out
//                          |                   |
//              SPI MOSI <--|P1.7/UCA0SIMO  P2.1|<-- SW UART RX In
//                          |                   |
//                          |                   |
//
//
//  Nathan Siegel
//  Texas Instruments Inc.
//  Sept. 2017
//  Built with IAR Embedded Workbench v7.10.2 & Code Composer Studio v7.2.0
//******************************************************************************
#include <msp430.h>
#include <stdint.h>

// Define pins
#define SPI_MOSI_PIN  BIT7      // SPI transmit pin, P1.7
#define SPI_MISO_PIN  BIT6      // SPI receive pin,  P1.6
#define SPI_CLK_PIN BIT5      // SPI CLK pin, P1.5
#define SW_TX_PIN   BIT0      // SW UART transmit pin, P2.0
#define SW_RX_PIN   BIT1      // SW UART receive pin,  P2.1

// Define parameters
#define SW_WHOLE_BIT 1666   // Full bit time, units are in clock cycles
                            // SW_WHOLE_BIT = SMCLK/SW UART baud rate
                            //              = 16MHz/9600 baud, SMCLK = 16MHz
                            //              = 1666 cycles

#define SW_HALF_BIT  833    // Half bit time, units are in clock cycles
                            // SW_HALF_BIT = SW_WHOLE_BIT/2 = 1666/2
                            //             = 833 cycles

#define SW_TOTAL_BITS 9     // 1 start bit, 8 data bits, 1 stop bit

// Define states
#define SPI_RX_STATE 1       // HW SPI receive state
#define SW_RX_STATE 2       // SW UART receive state

// Declare global variables
#if defined (__TI_COMPILER_VERSION__)
volatile uint16_t tempByte;                    // Stores data byte
volatile uint8_t bitCounter;                   // Tracks number of bits
volatile unsigned char currentState;           // Used to indicate state

#elif defined (__IAR_SYSTEMS_ICC__)
__no_init volatile uint16_t tempByte;          // Stores data byte
__no_init volatile uint8_t bitCounter;         // Tracks number of bits
__no_init volatile unsigned char currentState; // Used to indicate state
#endif

// Declare functions
void Timer_init(void)
{
    // Initialize Timer_B
    TB0CTL = TBCLR;                            // Clear configuration
    TB0CCTL0 = CCIE;                           // Enable TB0CCR0 interrupt
    TB0CCR0 = SW_HALF_BIT;                     // Delay before reading or
                                               // sending start bit

    TB0CTL = TBSSEL__SMCLK | MC__CONTINUOUS;   // SMCLK source, Continuous Mode
    bitCounter = 0;                            // Reset bit counter
}

// Main function
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;       // Stop watchdog timer
    FRCTL0 = FRCTLPW | NWAITS_1;    // Configure one FRAM waitstate as
                                    // required by the device datasheet for
                                    // MCLK operation beyond 8MHz _before_
                                    // configuring the clock system

    __bis_SR_register(SCG0);        // Disable FLL
    CSCTL3 |= SELREF__REFOCLK;      // Set REFO as FLL reference source
    CSCTL0 = 0;                     // clear DCO and MOD registers
    CSCTL1 &= ~(DCORSEL_7);         // Clear DCO frequency select bits first
    CSCTL1 |= DCORSEL_5;            // Set DCO = 16MHz
    CSCTL2 = FLLD_0 + 487;          // DCOCLKDIV = 16MHz
    __delay_cycles(3);              // Wait
    __bic_SR_register(SCG0);                   // Enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1)); // FLL locked

    CSCTL4 = SELMS__DCOCLKDIV | SELA__REFOCLK; // Set default REFO (~32768Hz)
                                               // as ACLK source, ACLK = 32768Hz
                                               // Default DCOCLKDIV as MCLK
                                               // and SMCLK source

    PM5CTL0 &= ~LOCKLPM5;                      // Disable GPIO power-on default
                                               // high-impedance mode

    // Initialize hardware UART pins
    P1SEL0 |= SPI_MISO_PIN | SPI_MOSI_PIN | SPI_CLK_PIN;      // Select SPI function

    // Initialize software UART pins, terminate unused GPIOs
    PADIR = 0xC1FF;                       // P2DIR = PADIR_H, P1DIR = PADIR_L
                                          // SW_TX_PIN (P2.0) = output
                                          // SW_RX_PIN (P2.1) = input

    PAOUT = 0x0100;                       // High (set UART idle state)
                                          // P2OUT = PAOUT_H, P1OUT = PAOUT_L
                                          // SW_TX_PIN (P2.0) = high

    P2IES |= SW_RX_PIN;                   // Select high-to-low interrupt edge
    P2IFG &= ~SW_RX_PIN;                  // Clear interrupt flag
    P2IE |= SW_RX_PIN;                    // Enable interrupt

    // Configure eUSCI_A SPI module
    UCA0CTLW0 = UCSWRST | UCSSEL__ACLK | UCMST | UCSYNC;  // Reset eUSCI
                                                           // Set SMCLK as BRCLK source
                                                           // Select master mode
                                                           // Enable Synchronous mode

    UCA0BRW = 0x0002;               // Bit rate clock = SMCLK/2 = 8 MHz

    UCA0CTLW0 &= ~UCSWRST;          // Release eUSCI_A UART module for operation
    UCA0IE = UCRXIE;                // Enable eUSCI_A RX interrupt

    // Enable global interrupts and enter LPM0
    __bis_SR_register(LPM0_bits + GIE);
}

// eUSCI_A interrupt service routine (SPI RX)
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
    {
        case USCI_SPI_UCRXIFG:

            UCA0IE &= ~UCRXIE;              // Disable eUSCI_A RX interrupt
            Timer_init();                   // Initialize and start Timer_B
                                            // NOTE: This function inside this
                                            // ISR was used to reduce code size,
                                            // but it is NOT recommended in
                                            // general. Instead, consider
                                            // inlining or moving the function
                                            // call outside the ISR.

            tempByte = UCA0RXBUF << 1;      // Store data byte and add start bit
            tempByte |= 0x0200;             // Add stop bit
            currentState = SPI_RX_STATE;     // Change states
            break;                          // Exit case

        default: break;                     // All other cases
    }
}

// Port 2 interrupt service routine (SW UART RX)
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
    P2IE &= ~SW_RX_PIN;                     // Disable software RX interrupt
    P2IFG &= ~SW_RX_PIN;                    // Clear interrupt flag
    Timer_init();                           // Initialize and start Timer_B
                                            // NOTE: This function inside this
                                            // ISR was used to reduce code size,
                                            // but it is NOT recommended in
                                            // general. Instead, consider
                                            // inlining or moving the function
                                            // call outside the ISR.

    tempByte = 0;                           // Reset temporary byte
    currentState = SW_RX_STATE;             // Change states
}

// Timer_B interrupt service routine (SW UART TX or RX)
#pragma vector = TIMER0_B0_VECTOR
__interrupt void Timer0_B0_ISR(void)
{
    // Start, data, and stop bits
    if(bitCounter <= SW_TOTAL_BITS)
    {
        // Increment delay for reading or sending next bit
        TB0CCR0 += SW_WHOLE_BIT;

        // If data byte was received by HW UART, send data byte using SW UART
        if(currentState == SPI_RX_STATE)
        {
            // If start, data, or stop bit is high, send high bit
            if(tempByte & 0x0001)
            {
                P2OUT |= SW_TX_PIN;         // Output high
            }

            // Otherwise, send low bit
            else
            {
                P2OUT &= ~SW_TX_PIN;        // Output low
            }
        }

        // Shift all bits to right
        tempByte = tempByte >> 1;

        // If start bit was received by SW UART, start reading data bits
        if(currentState == SW_RX_STATE && bitCounter > 0)
        {
            // At stop bit, stop the timer and send data byte using HW UART
            if(bitCounter == SW_TOTAL_BITS)
            {
                TB0CTL = MC_0;              // Stop Timer_B immediately

                #if defined (__TI_COMPILER_VERSION__)
                while(!(UCA0IFG&UCTXIFG));  // Check TXIFG before sending
                                            // NOTE: This check was removed in
                                            // IAR to allow code to fit, since
                                            // the UCTXIFG flag will get reset
                                            // before new data is loaded into
                                            // TXBUF. In general, this is NOT
                                            // recommended! See Section 21.3.8
                                            // in the UG.
                #endif

                UCA0TXBUF = tempByte;       // Send data byte over SPI
                P2IFG &= ~SW_RX_PIN;        // Clear interrupt flag
                P2IE |= SW_RX_PIN;          // Re-enable software RX interrupt
            }

            // If data bit is high, update temporary byte accordingly
            else if((P2IN & SW_RX_PIN) == SW_RX_PIN)
            {
                tempByte |= 0x0100;         // Update data bit before shift
            }
        }

        // Increment bit counter
        bitCounter++;
    }

    // Ensures that stop bit has been sent by SW UART
    else
    {
        TB0CTL = MC_0;                      // Stop Timer_B immediately
        UCA0IE = UCRXIE;                    // Re-enable eUSCI_A RX interrupt
    }
}

/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Stepper Motor Control
//
//  Description: This code shows how to control a stepper motor using eleven
//  different UART commands that change the frequency and duty cycle of a
//  PWM signal along with motor directionality. This demonstration requires a
//  DRV8825 or similar stepper motor driver.  UART is sourced by SMCLK (~8 MHz)
//  at 9600 baud with one 1 stop bit and no parity.  SMCLK also sources TB0
//  with a frequency (CCR0) dependent on the desired speed, with the duty cycle
//  (CCR1) adjusting to maintain 50%.  UART input 0x00 turns the motor off, 0x0A
//  reverses direction, and 0x01 to 0x09 changes the speed from slowest (1 kHz)
//  to fastest (250 kHz), respectively, but also depends on the motor driver and
//  power supply limitations.    The device typically operates in LPM0.
//
//  ACLK = REFO = 32768Hz, MCLK = SMCLK = DCODIV = 8MHz.
//
//                MSP430FR2000
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST              |
//            |     P2.0/TB0.1  |--> CCR1 - PWM
//            |                 |
//            |     P2.1/TB0.2  |--> GPIO - DIR
//            |                 |
//            |     P1.6/UCA0RXD|<-- PC
//            |                 |
//
//   T. Black & R. Brown
//   Texas Instruments Inc.
//   Aug. 2017
//   Built with Code Composer Studio v7.2
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

 //Create global look-up table for different frequency & duty cycle values
 //For example: 8 MHz / 1 kHz = 8000, 8 MHz / 2 kHz = 4000, etc.
 const uint16_t frequencyTable [10] = {0,8000,4000,2000,
                                         1000,500,250,125,
                                         64,32};

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;                   // Stop watchdog timer

    __bis_SR_register(SCG0);                    // disable FLL
    CSCTL3 |= SELREF__REFOCLK;                  // Set REFO as FLL reference source
    CSCTL0 = 0;                                 // clear DCO and MOD registers
    CSCTL1 &= ~(DCORSEL_7);                     // Clear DCO frequency select bits first
    CSCTL1 |= DCORSEL_5;                        // Set DCO = 16MHz
    CSCTL2 = FLLD_0 + 487;                      // DCOCLKDIV = 16MHz
    __delay_cycles(3);
    __bic_SR_register(SCG0);                    // enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));  // FLL locked

    CSCTL4 = SELMS__DCOCLKDIV | SELA__REFOCLK;  // set default REFO(~32768Hz) as ACLK source, ACLK = 32768Hz
                                                // default DCOCLKDIV as MCLK and SMCLK source
    CSCTL5 |= DIVM__2;                          // SMCLK = MCLK = DCO/2 = 16 MHz/2 = 8 MHz

    // Configure GPIO
    PADIR = 0xFFFF;
    PAREN = 0xFFFF;
    PAOUT = 0x0000;

    // Configure P1.6 for UCA0RXD and P2.0 for CCR1
    PASEL0 = BIT6 + BIT8;

    // Disable the GPIO power-on default high-impedance mode
    // to activate 1previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    // Configure UART
    UCA0CTLW0 = UCSWRST + UCSSEL__SMCLK;        // set SMCLK as BRCLK

    // Baud Rate calculation. Referred to UG 17.3.10
    // (1) N=8000000/9600/16=52.08
    // (2) OS16=1, UCBRx=INT(N)=52
    // (4) Fractional portion = 0.08. Referred to UG Table 17-4, UCBRSx=0x49.
    UCA0BRW = 52;                               // INT(8000000/9600/16)
    UCA0MCTLW = 0x4900 + UCOS16 + UCBRF_1;

    UCA0CTLW0 &= ~UCSWRST;                      // Initialize eUSCI
    UCA0IE = UCRXIE;                            // Enable USCI_A0 RX interrupt

    TB0CCR0 = 0;                                // PWM Period (off)
    TB0CCR1 = 0;
    TB0CCTL1 = OUTMOD_7;                        // CCR1 reset/set
    TB0CTL = TBSSEL__SMCLK | MC__UP | TBCLR;    // SMCLK, up mode, clear TBR

    __bis_SR_register(LPM0_bits|GIE);           // Enter LPM0, interrupts enabled
    __no_operation();                           // For debugger
}


//------------------------------------------------------------------------------
// eUSCI A0 UART interrupt service routine.
// Uses P1.6/UCA0RXD to receive a hex character and change the stepper motor
// speed dependent on the value supplied
//------------------------------------------------------------------------------
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    uint8_t RXData;
    switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
    {
        case USCI_UART_UCRXIFG:
            RXData = UCA0RXBUF;
            if (RXData == 0x0A) P2OUT ^= BIT1;      // Toggle direction of motor
            else if (RXData <= 0x09)                // Number between 0x0 and 0x9
            {
                // Set frequency and duty cycle values from look-up table
                // Based on 0x00 to 0x09 value of UART input
                TB0CCR0 = frequencyTable[RXData];
                TB0CCR1 = frequencyTable[RXData]>>1;
            }
            break;
        default: break;
    }
}

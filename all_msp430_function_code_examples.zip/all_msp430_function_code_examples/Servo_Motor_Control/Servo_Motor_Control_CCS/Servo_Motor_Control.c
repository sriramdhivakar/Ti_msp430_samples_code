/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Servo Motor Control
//
//  Description: This code shows how to control a servo motor using sixteen
//  different hex UART commands that change the duty cycle of a PWM signal. This
//  demonstration requires the MSP430 CCR1 pin (2.0) to be stepped up to 5 V.
//  UART is sourced by ACLK (32768 MHz) at 4800 baud with one 1 stop bit and no
//  parity.  UART input 0x00 represents 0 degrees (1 ms high or 5%) and 0x0F
//  positions 180 degrees (2 ms or 10 %, with equal steps in between.  All other
//  values are ignored.  ACLK also sources TB0 with a 50 Hz frequency required
//  for servo motor control.  The device normally operates in LPM3.
//
//  ACLK = REFO = 32768Hz, MCLK = SMCLK = DCODIV ~1MHz.
//
//                MSP430FR2000
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST              |
//            |                 |
//            |     P2.0/TB0.1  |--> CCR1 - PWM
//            |                 |
//            |     P1.6/UCA0RXD|<-- PC
//            |                 |
//
//   T. Black & R. Brown
//   Texas Instruments Inc.
//   Aug. 2017
//   Built with Code Composer Studio v7.2
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

#pragma PERSISTENT(savedState)          // Stores saved servo state
 uint8_t savedState = 0;

//Create global look-up table for different duty cycle values
const uint8_t dutyCycleTable [16] = {33,36,38,40,
                                        42,44,46,48,
                                        50,52,54,56,
                                        58,60,62,65};

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // Stop watchdog timer

    // Configure GPIO
    PADIR = 0xFFFF;
    PAREN = 0xFFFF;
    PAOUT = 0x0000;

    // Configure P1.6 for UCA0RXD and P2.0 for CCR1
    PASEL0 = BIT6 + BIT8;

    // Disable the GPIO power-on default high-impedance mode
    // to activate 1previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    // Configure UART
    UCA0CTLW0 = UCSWRST + UCSSEL__ACLK;         // set ACLK as BRCLK

    // Baud Rate calculation. Referred to UG 17.3.10
    // (1) N=32768/4800=6.827
    // (2) OS16=0, UCBRx=INT(N)=6
    // (4) Fractional portion = 0.827. Referred to UG Table 17-4, UCBRSx=0xEE.
    UCA0BRW = 6;                               // INT(1048576/4800/16)
    UCA0MCTLW = 0xEE00;

    UCA0CTLW0 &= ~UCSWRST;                      // Initialize eUSCI
    UCA0IE = UCRXIE;                            // Enable USCI_A0 RX interrupt

    TB0CCR0 = 655;                              // PWM Period (20ms, 32768/50)
    TB0CCR1 = dutyCycleTable[savedState];
    TB0CCTL1 = OUTMOD_7;                        // CCR1 reset/set
    TB0CTL = TBSSEL__ACLK | MC__UP | TBCLR;     // ACLK, up mode, clear TBR

    __bis_SR_register(LPM3_bits|GIE);           // Enter LPM0, interrupts enabled
    __no_operation();                           // For debugger
}

//------------------------------------------------------------------------------
// eUSCI A0 UART interrupt service routine.
// Uses P1.6/UCA0RXD to receive a hex character and change the servo motor
// position dependent on the value supplied
//------------------------------------------------------------------------------
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
    {
        case USCI_UART_UCRXIFG:
            if (UCA0RXBUF <= 0x0F)                      // Valid hexadecimal input?
            {
                SYSCFG0 = FRWPPW;                       // FRAM write enable
                savedState = UCA0RXBUF;                 // Save the data state
                SYSCFG0 = FRWPPW | PFWP;                // FRAM write disable
                TB0CCR1 = dutyCycleTable[savedState];   // Adjust duty cycle accordingly
            }
            break;
        default: break;
    }
}

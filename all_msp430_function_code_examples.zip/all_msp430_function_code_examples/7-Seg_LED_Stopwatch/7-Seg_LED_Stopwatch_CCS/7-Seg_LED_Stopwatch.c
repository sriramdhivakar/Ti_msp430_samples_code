/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Demo - RTC, A Stopwatch demo with three 7-Seg LEDs to show out
//                      the time,two buttons to control the stopwatch. One button
//                      is for the Start/Stop function, the other button is for
//                      the Reset function.
//
//  Description: Configure ACLK to use REFO as RTC source clock,
//               ACLK = REFO = ~32768kHz, MCLK = SMCLK = default DCODIV = ~1MHz.
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |           P1.0|
//        |             ~ |---> 7-seg LED display(segment)
//        |           P1.6|
//        |               |
//        |           P1.7|
//        |           P2.0|---> 7-seg LED display(position)
//        |           P2.1|
//        |               |
//        |           P2.6|<-- Button 1(Start/Stop)
//        |           P2.7|<-- Button 2(Reset)
//
//   Cash Hao
//   Texas Instruments Inc.
//   Sept 2017
//   Built with Code Composer Studio v7.2 and IAR 7.10
//******************************************************************************
#include <msp430.h> 

/* Constant Definitions */
const unsigned char SEVENSEG_OUTPUT[10] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f}; //7-seg LED display from "0" to "9"

/* Global Variables */
unsigned char timeCounter1, timeCounter2, timeCounter3, loopCounter; //three LED display numbers

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer

    PADIR = 0x03ff;                         // P1, P2.0 and P2.1 output, P2.6 and P2.7 input
    PAOUT = 0xc03f;

    P2REN = 0xc0;                           // P2.6 P2.7 pull-up register enable
    P2IES = 0x3f;                           // P2.6 P2.7 Low to High edge
    P2IE = 0xc0;                            // P2.6 P2.7 interrupt enabled

    PM5CTL0 &= ~LOCKLPM5;                   // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings

    RTCMOD = 50;                            // RTC count re-load compare value at 50.
                                            // 64/32768 * 51 = ~0.1 sec.
    SYSCFG2 |= RTCCKSEL;                    // Source = ACLK = REFO, divided by 64, Select ACLK as RTC clock
    RTCCTL = RTCSS_1 | RTCSR | RTCPS__64;

    P2IFG = 0;                              // P1.3 IFG cleared

    __bis_SR_register(GIE);

    while(1)
    {
        PAOUT |= (BIT9 | SEVENSEG_OUTPUT[timeCounter3]);  // Show the time on the LEDs in order
        __delay_cycles(100);                              // LED hold time
        PAOUT = 0xc000;                                   // Clear the Pins

        PAOUT |= (BIT8 | SEVENSEG_OUTPUT[timeCounter2]);
        __delay_cycles(100);
        PAOUT = 0xc000;

        P1OUT |= (BIT7 | SEVENSEG_OUTPUT[timeCounter1]);
        __delay_cycles(100);
        P1OUT = 0;
    }
}


// RTC interrupt service routine
#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
    RTCIV = 0;
    timeCounter1++;                         // timeCounter1 represents 0.1s, timeCounter2 represents 1s,
                                            // timeCounter3 represents 10s

    if(timeCounter1 > 9)                    // When timeCounter1 count to 10, clear timeCounter1
                                            // and let timeCounter2 add one. When timeCounter2 count to 10,
                                            // clear timeCounter2 and let timeCounter3 add one
    {
        timeCounter1 = 0;
        timeCounter2++;
        if(timeCounter2 > 9)
        {
            timeCounter3++;
            timeCounter2 = 0;
        }
        if(timeCounter3 > 9)
        {
            timeCounter3 = 0;
        }

    }
}

// Port 2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void)
{
    if(P2IFG & BIT6)
    {
        P2IFG &= ~BIT6;                       // Clear P2.6 IFG, for start/stop the stopwatch
            if(loopCounter == 0)
            {
                loopCounter++;                // For the first time press down the button, it
                                              // should start the timer. For the second time
                                              // press the button, it should stop the timer.
                RTCCTL |= RTCIE;
            }
            else
            {
                RTCCTL &= ~RTCIE;
                loopCounter = 0;
            }
    }
    if(P2IFG & BIT7)
    {
        P2IFG &= ~BIT7;                       // Clear P2.7 IFG, for restart the stopwatch

        RTCCTL &= ~RTCIE;                     // Stop the timer
        loopCounter = 0;

        timeCounter3 = 0;
        timeCounter2 = 0;
        timeCounter1 = 0;
    }

}


/* --COPYRIGHT--,BSD-3-Clause
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
// MSP430FR2xxx Demo - Simple Power Sequencer
//
// Description: Programmable power sequencer emulating the LM3880. After startup
//              and initialization, the code follows the basic structure outlined
//              below:
//
//      1. Enter LPM4
//      2. Wake on EN signal rising edge
//      3. Enter EN pin ISR
//         a. Start Timer_B count
//         b. Clear EN IFG
//         c. Configure to use power-up sequence
//      4. Enter LPM3
//      5. Wake on TB0.0 interrupt
//      6. Enter TB0.0 ISR
//         a. Toggle flag output level
//         b. Point to next flag or stop timer
//      7. Repeat from step 4 until end of power-up sequence
//      8. Enter LPM4
//      9. Wake on EN signal falling edge
//     10. Enter EN pin ISR
//         a. Start Timer_B count
//         b. Clear EN IFG
//         c. Configure to use power-down sequence
//     11. Enter LPM3
//     12. Wake on TB0.0 interrupt
//     13. Enter TB0.0 ISR
//         a. Toggle flag output level
//         b. Point to next flag or stop timer
//     14. Repeat from step 11 until end of power-down sequence
//     15. Repeat from step 1
//
//   ACLK = ~32768Hz, MCLK = SMCLK = default DCODIV ~1.048MHz.
//
//           MSP430FR2xxx
//         ---------------
//        |      (P2.7)XIN|--
//     /|\|               |  ~32768Hz (optional)
//      | |     (P2.6)XOUT|--
//      --|RST            |
//        |           P1.0|<--o--- EN
//        |               |   |
//        |               | 1M Ohm
//        |               |   |
//        |               |  GND
//        |               |
//        |           P1.7|--> FLAG1
//        |           P2.0|--> FLAG2
//        |           P2.1|--> FLAG3
//
//   Caleb Overbay
//   Texas Instruments Inc.
//   March 2018
//   Built with Code Composer Studio v7.2, compiler version TIv16.9.6.LTS
//******************************************************************************

#include <msp430.h> 
#include <stdbool.h>
#include <stdint.h>

#define USE_REFO  // USE_LFXT = External crystal, USE_REFO = Internal osc.

// Set to the desired delay
#define RAIL_DELAY   33    // ~1ms

// Enable pin defines
#define EN_DIR P1DIR
#define EN_IES P1IES
#define EN_IE  P1IE
#define EN_IFG P1IFG
#define EN_BIT BIT0

#define NULL    0x0000  // Null representation

// Individual linked list node
typedef struct node_s{
    uint16_t bit;
    const struct node_s* next;
}node_t;

// Local function definitions
static inline void GPIO_init(void);
static inline void TimerB_init(void);

// Linked list representing power-up sequence
const node_t p21_up_node = {.bit = BIT9, .next = NULL};          // P2.1
const node_t p20_up_node = {.bit = BIT8, .next = &p21_up_node};  // P2.0
const node_t p17_up_node = {.bit = BIT7, .next = &p20_up_node};  // P1.7

// Linked list representing power-down sequence
const node_t p17_dn_node = {.bit = BIT7, .next = NULL};  // P1.7
const node_t p20_dn_node = {.bit = BIT8, .next = &p17_dn_node};  // P2.0
const node_t p21_dn_node = {.bit = BIT9, .next = &p20_dn_node};  // P2.1

const node_t *currNode;   // Tracks the current node in the list
const node_t * const power_up_head = &p17_up_node; // Head of power-up seq.
const node_t * const power_dn_head = &p21_dn_node; // Head of power-down seq.

/**
 * main.c
 */
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop WDT

    GPIO_init();      // Initialize GPIO
    TimerB_init();    // Initialize TimerB

    __bis_SR_register(LPM4_bits | GIE); // Enter LPM4, never exiting
}

/*
 * Initializes unused GPIO to output low for best power consumption
 * Configures EN pin as input to trigger on rising edge
 * Disables GPIO power-on default high-impedance state
 */
static inline void GPIO_init(void)
{
    // Set all GPIO to output low for lowest power consumption
    PAOUT = 0x0000;
    PADIR = 0xFFFF;

    EN_DIR &= ~EN_BIT;  // Set EN pin as input
    EN_IES = 0x00;      // EN pin will trigger on a rising edge
    EN_IE = EN_BIT;     // EN pin interrupt enabled

    // Disable the GPIO power-on default high-impedance mode
    // to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    EN_IFG = 0x00;  // Clear any pending EN port interrupts

#ifdef USE_LFXT
//Use XT1 as FLL reference clock

        P2SEL1 = BIT6 | BIT7;    //Set 2.6 and P2.7 as XT1 pins

        // Loop until XT1 is stable
        do
        {
            CSCTL7 &= ~(XT1OFFG | DCOFFG);     // Clear XT1 and DCO fault flag
            SFRIFG1 &= ~OFIFG;
        } while (SFRIFG1 & OFIFG);             // Test oscillator fault flag


        CSCTL4 = SELA__XT1CLK;    // Source ACLK from XT1 (32768 Hz)
#endif
}

/*
 * Initializes TimerB, TB0.1 and TB0.2 output
 */
static inline void TimerB_init(void)
{
    // Setup the delay
    TB0CCR0 = RAIL_DELAY;

    // Enable interrupts on all the CCRx registers
    TB0CCTL0 = CCIE;             // Enable CCR0/FLAG1 interrupts
}

/*
 * TimerB Interrupt service routine (TB0.0)
 *
 * Entered when TBR reaches TB0.0 (CCR0) value.
 * Signals either the begin or end of the power sequencing
 */
#pragma vector=TIMER0_B0_VECTOR
__interrupt void TIMER0_B0_ISR(void)
{
    PAOUT ^= (*currNode).bit;          // Toggle output

    // Check if the next node in the list is null
    if((*currNode).next != NULL)
    {
        currNode = (*currNode).next;  // Change to next node
    }
    else
    {// End of sequence
        TB0CTL = 0x00;       // Stop timer
        EN_IES ^= EN_BIT;    // Toggle trigger edge
    }
}

/*
 * Port 1 interrupt service routine
 */
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    // Src=ACLK=32768kHz, Up Mode, Clear Timer
    TB0CTL = TBSSEL_1 + MC_1 + TBCLR;     // Start Timer

    EN_IFG &= ~EN_BIT;         // Clear Enable IFG

    if(EN_IES & EN_BIT)
    {// Triggered on a falling edge, power down sequence
        currNode = power_dn_head;
    }
    else
    { // Triggered on a rising edge, power up sequence
        currNode = power_up_head;
    }
}


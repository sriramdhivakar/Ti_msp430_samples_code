/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Demo - Programmable Wake-up Controller
//
//  Description: Configure ACLK to use XT1 as RTC source clock,
//               ACLK = REFO = 32kHz, MCLK = SMCLK = default DCODIV = ~1MHz.
//               RX (SPI) RTC MOD (Interval) and increment, then start RTC at
//               these values
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |          P1.0 |--> Host (Interrupt Host)
//        |               |
//        |          P1.3 |<-- Chip Select  (Active High, Idle Low)
//        |          P1.5 |<-- Serial Clock In (UCA0CLK) (Idle Low)
//        |          P1.7 |<-- Data IN (UCA0SIMO)
//        |               |
//        |          P2.6 |--> XOUT 32768 XTAL
//        |          P2.7 |<-- XIN
//
//   Jace Hall
//   Texas Instruments Inc.
//   August 2017
//   Built with Code Composer Studio v7.2 and IAR 7.10
//******************************************************************************
#include <msp430.h>
#include <stdint.h>

#if defined(__IAR_SYSTEMS_ICC__)
__no_init volatile uint8_t timeIncrement; // RTC Overflow Counter
__no_init volatile uint8_t increment;     // RTC Count Value
__no_init volatile uint8_t RX_count;      // SPI RX Counter
__no_init volatile uint16_t RX_temp;       // SPI Temp Variable
 #elif defined(__TI_COMPILER_VERSION__)
volatile uint8_t timeIncrement;   // RTC Overflow Counter
volatile uint8_t increment;       // RTC Count Value
volatile uint8_t RX_count;        // SPI RX Counter
volatile uint16_t RX_temp;         // SPI Temp Variable
#endif

#define MAX_RX_COUNT (6)

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;        // Stop watchdog timer

    // Configure GPIO
    P1OUT  = 0x00;                   // Clear P1.0 output latch
    P1DIR  = BIT0;                   // Set P1.0 to output direction
    P1REN = BIT3;                    // P1.3 pull-down register enable
    P1IES  = 0x00;                   // P1.3 Low/High edge
    P1SEL0 = BIT5 | BIT7;            // set 3-SPI pin as second function
    P2SEL1 = BIT6 | BIT7;            // P2.6~P2.7: crystal pins
    P2OUT = 0x00;                    // Unused pins to LP State
    P2DIR = 0xFF;
    PM5CTL0 &= ~LOCKLPM5; // Disable the GPIO power-on default high-impedance
                         // mode to activate previously configured port settings

    // Initialize crystal and clocks
    // Configure one FRAM waitstate as required by the device datasheet for MCLK
    // operation beyond 8MHz _before_ configuring the clock system.
    FRCTL0 = FRCTLPW | NWAITS_1;
    do
    {
        CSCTL7 &= ~(XT1OFFG | DCOFFG);       // Clear XT1 and DCO fault flag
        SFRIFG1 &= ~OFIFG;
    } while (SFRIFG1 & OFIFG);               // Test oscillator fault flag

    __bis_SR_register(SCG0);                 // disable FLL
    CSCTL3 |= SELREF__XT1CLK;                // Set XT1 as FLL reference source
    CSCTL0 = 0;                              // clear DCO and MOD registers
    CSCTL1 &= ~(DCORSEL_7);            // Clear DCO frequency select bits first
    CSCTL1 |= DCORSEL_5;                    // Set DCO = 16MHz
    CSCTL2 = FLLD_0 + 487;                  // DCOCLKDIV = 16MHz
    __delay_cycles(3);
    __bic_SR_register(SCG0);                     // enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));   // FLL locked

    CSCTL4 = SELMS__DCOCLKDIV | SELA__XT1CLK;   // set XT1 (~32768Hz) as ACLK
                                            //  source, ACLK = 32768Hz default
                                           //DCOCLKDIV as MCLK and SMCLK source
    UCA0CTLW0 |= UCSWRST;                     // *Put state machine in reset*
    UCA0CTLW0 |= UCSYNC |UCMSB;               // 3-pin, 8-bit SPI slave
                                              // Clock polarity low, MSB
    UCA0CTLW0 &= ~UCSWRST;                    // *Initialize USCI state machine*
    P1IE   = BIT3;                   // P1.3 interrupt enabled, Chip Select (CS)
    __bis_SR_register(LPM3_bits | GIE);       // Enter LPM3, enable interrupt
}

// RTC interrupt service routine

#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
    switch(__even_in_range(RTCIV, RTCIV__RTCIFG))
    {
        case  RTCIV__NONE:   break;           // No interrupt
        case  RTCIV__RTCIFG:                  // RTC Overflow
            if(timeIncrement >= increment)
            {
                P1OUT = BIT0;                 // Wake-up Host
                timeIncrement =0;             // Clear SW Counter
                P1IFG = 0x00;                 // Clear P1.3 IFG
                P1IE = BIT3;                  // Enable CS Line
                RTCCTL = 0; // Stop RTC
                P1OUT = 0;
            }
            else
            {
                timeIncrement++;              // Increment SW Counter
            }
            break;
        default: break;
    }
}
// Port 1 interrupt service routine
//Chip Select for the SPI
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    RTCMOD = 0x00;                        // Clear Application Variables
    increment = 0;
    timeIncrement = 0;
    RX_count = 0;
    P1IE  = 0x00;                         // Disable CS Line
    P1IFG = 0x00;                         // Clear P1.3 IFG
    UCA0IE = UCRXIE;                      // Enable USCI_A0 RX interrupt
    __bis_SR_register_on_exit(LPM0_bits | GIE);
}


#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    switch(__even_in_range(RX_count, 4))
    {
        case 0:                     // RX Byte 1: SW Counter
            increment = UCA0RXBUF;
            RX_count += 2;
            break;

        case 2:                     // RX Byte 2: RTCMOD High Byte
            RX_temp = UCA0RXBUF;
            RX_temp = (RX_temp << 8);
            RX_count += 2;
            break;

        case 4:                     // RX Byte 3: RTCMOD Low Byte
            RX_temp |= UCA0RXBUF;
            RTCMOD = RX_temp;
            RTCCTL = RTCSS_2 | RTCSR | RTCPS__1024 | RTCIE; // Start RTC
            UCA0IE = 0;             // Disable USCI_A0 RX interrupt
            RX_count +=2;
            break;
    }
    if(RX_count >= MAX_RX_COUNT)    // check for all byte RX
    {
        RX_count =0;
        __bis_SR_register_on_exit(LPM3_bits | GIE);
    }
}

/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Tamper Detection Demo
//
//  Description: Tamper detection warning system. P1.1 outputs the clock signal
//  for the Auxiliary clock (ACLK) which should be connected to P1.0. P1.0
//  counts the number of falling edges on the clock signal over a set time
//  interval controlled by the real time clock (RTC). The RTC is sourced by
//  ACLK. If the count generated from the number of falling edges seen on P1.1
//  does not match the expected value over a time interval, P2.0 will rise from
//  '0' to '1' until it matches the expected count on a following time interval
//  at which point its value will change to '0' again. This example also shows
//  how to erase a persistent variable in FRAM representing secure data if a
//  tampering event is detected.
//
//
//  ACLK = default REFO ~32768Hz or XT1CLK if EXT_OSC set to '1'
//  MCLK = SMCLK = ~16MHz.
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST        P2.0|--> WARN     |
//        |               |
//        |           P1.1|-->-+  ACLK
//        |           P1.0|<---+
//        |               |
//
//   Ryan Meredith
//   Texas Instruments Inc.
//   September 2017
//   Built with IAR Embedded Workbench v7.10.5 & Code Composer Studio v7.2
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>

#define EXT_OSC         0
#define ACLK_FREQ       32768   // Hz
#define RTC_DIV         16      // must match RTCPS value in RTCCTL

#define CHECK_TIME      1/2048  // seconds (enter multiple of min time)
                                // min time: RTC_DIV/ACLK_FREQ
                                // max time: 2^16*(min time)

#define CHECK_CYCLES    ACLK_FREQ/RTC_DIV*CHECK_TIME
#define CHECK_COUNT     ACLK_FREQ*CHECK_TIME*2
// Note: pre-processor will truncate calculations to integers. For best results
//       ACLK_FREQ and RTC_DIV should be powers of 2 and CHECK_TIME guidelines
//       should be followed to ensure CHECK_CYCLES and CHECK_COUNT are integers.

#define UPPER_TOL       1
#define LOWER_TOL       1

// Global Variables
#if defined(__TI_COMPILER_VERSION__)
uint32_t count;
uint8_t startFlag;
#elif defined(__IAR_SYSTEMS_ICC__)
__no_init uint32_t count;
__no_init uint8_t startFlag;
#else
#error Compiler not supported!
#endif

// Statically-initialized Variable
#if defined(__TI_COMPILER_VERSION__)
#pragma PERSISTENT(secureData)
uint32_t secureData = 0xC0DE4B1D;
#elif defined(__IAR_SYSTEMS_ICC__)
__persistent uint32_t secureData = 0xC0DE4B1D;
#else
#error Compiler not supported!
#endif

/**
 * main.c
 */
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    startFlag = 0;

    // Configure GPIO
    // Set P1.1 as output for ACLK
    P1DIR |= BIT1;
    P1OUT |= BIT1;

    // Set P1.0 as input for ACLK
    P1OUT |= BIT0;
    P1REN |= BIT0;

    // Set P2.0 to output detected tampering
    P2DIR |= BIT0;              // Set P2.0 as output for detected tamper
    P2OUT &= ~BIT0;             // Clear output value

    // Set system clock to 16 MHz to handle interrupts fast enough

    // Configure one FRAM waitstate as required by the device datasheet for MCLK
    // operation beyond 8MHz _before_ configuring the clock system.
    FRCTL0 = FRCTLPW | NWAITS_1;

    __bis_SR_register(SCG0);    // disable FLL
    CSCTL3 |= SELREF__REFOCLK;  // Set REFO as FLL reference source
    CSCTL0 = 0;                 // clear DCO and MOD registers
    CSCTL1 &= ~(DCORSEL_7);     // Clear DCO frequency select bits first
    CSCTL1 |= DCORSEL_5;        // Set DCO = 16MHz
    CSCTL2 = FLLD_0 + 487;      // set to fDCOCLKDIV = (FLLN + 1)*(fFLLREFCLK/n)
                                //                   = (487 + 1)*(32.768 kHz/1)
                                //                   = 16 MHz
    __delay_cycles(3);
    __bic_SR_register(SCG0);                        // enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));      // FLL locked

#if EXT_OSC
    CSCTL4 = SELMS__DCOCLKDIV | SELA__XT1CLK;

    P2SEL1 |= BIT6 | BIT7;                  // P2.6~P2.7: crystal pins
    do
    {
        CSCTL7 &= ~(XT1OFFG | DCOFFG);      // Clear XT1 and DCO fault flag
        SFRIFG1 &= ~OFIFG;
    } while (SFRIFG1 & OFIFG);              // Test oscillator fault flag

#else
    CSCTL4 = SELMS__DCOCLKDIV | SELA__REFOCLK;
#endif

    // Set P1.1 to output ACLK
    P1SEL1 |= BIT1;

    // set interrupts
    P1IES |= BIT0;
    P1IFG = 0;                              // Clear all P1 interrupt flags
    P1IE = BIT0;

    // Unlock GPIO
    PM5CTL0 &= ~LOCKLPM5;

    // check counts every CHECK_TIME second
    RTCMOD = CHECK_CYCLES - 1;

    // Initialize RTC
    SYSCFG2 |= RTCCKSEL;    // Make ACLK available to use for RTC

    // RTCSS_1: selects ACLK as RTC source
    // RTCSR:   clear the RTC counter value
    // RTCIE:   enable RTC interrupt
    //
    // Macro      | RTC Prescaler
    // ------------------------
    // RTCPS_16   | 16
    // RTCPS_64   | 64
    // RTCPS_256  | 256
    // RTCPS_1024 | 1024
    RTCCTL = RTCSS_1 | RTCSR | RTCPS__16 | RTCIE;

    count = 0;

    while (1){
        __bis_SR_register(LPM3_bits | GIE);     // Enter LPM3, enable interrupts
        __no_operation();                       // For debugger
    }
}

// RTC interrupt service routine
#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void){

    switch(__even_in_range(RTCIV,RTCIV_RTCIF))
    {
        case  RTCIV_NONE:   break;          // No interrupt
        case  RTCIV_RTCIF:                  // RTC Overflow
            // only check time intervals after first one
            if (!startFlag){
                startFlag = 1;
            }
            // raise warning if the count is not correct
            else if ((count < (CHECK_COUNT - LOWER_TOL))
                    || (count > CHECK_COUNT + UPPER_TOL)){
                P2OUT |= BIT0;
                SYSCFG0 = FRWPPW;           // Program FRAM write enable
                secureData = 0xFFFFFFFF;    // Erase protected data
                SYSCFG0 = FRWPPW | PFWP;    // Program FRAM write protected
            }
            // clear warning if count is in the correct range
            else {
                P2OUT &= ~BIT0;
            }
            count = 0;
            break;
        default: break;
    }
}

// Port 1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void port1_ISR(void){

    switch(__even_in_range(P1IV, P1IV__P1IFG7)) {
        case P1IV__NONE:   break;   // No interrupt
        case P1IV__P1IFG0:          // Edge on P1.0
            P1IES ^= BIT0;          // toggle edge trigger
            count += 1;             // increment counter
            break;
        case P1IV__P1IFG1: break;
        case P1IV__P1IFG2: break;
        case P1IV__P1IFG3: break;
        case P1IV__P1IFG4: break;
        case P1IV__P1IFG5: break;
        case P1IV__P1IFG6: break;
        case P1IV__P1IFG7: break;
        default:   break;
    }
}

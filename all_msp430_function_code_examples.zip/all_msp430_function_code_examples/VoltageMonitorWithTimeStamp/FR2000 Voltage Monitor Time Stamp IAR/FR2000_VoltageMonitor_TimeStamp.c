/* --COPYRIGHT--,BSD-3-Clause
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Voltage Monitor with Time-stamp
//
//  Description: Voltage Monitor based on eCOMP with internal 1.5V reference.
//  The MSP430 uses the RTC counter module to increment the timestamp 1/sec.
//  The UART should be used to set an initial time at first startup and the
//  RTC will increment from there. The timestamp is in POSIX time format.
//  The timestamp can be read out over UART by a host controller, so the MSP430
//  is acting as an external RTC to keep time. If the input voltage on C1 is lower
//  than the threshold, the timestamp will be stored in FRAM so it will be
//  retained through a power loss.
//
//  Communications Protocol (UART)
//  ----------------------------------------------------------------------
//  [READ/WRITE] <data> <data> <data> <data>
//  READ = 00h, WRITE = 01h,
//
//  WRITE TIME: 01h XXh XXh XXh XXh
//  READ TIME:  00h     RESPONSE: XXh XXh XXh XXh
//  ----------------------------------------------------------------------
//
//  XT1 requires a 32768Hz crystal oscillator for this example.
//  ACLK = XT1 = 32768Hz, MCLK = SMCLK = default DCODIV ~1.048MHz.
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |        P1.1/C1|<-- Voltage Monitoring
//      --|RST            |
//        |               |
//        |           P1.7|--> UCA0TXD
//        |           P1.6|<-- UCA0RXD
//        |               |
//        |           P2.6|--> XOUT 32768 XTAL
//        |           P2.7|<-- XIN
//        |               |
//
//
//   Created by Katie Pier | Updated by Darren Lu
//   Texas Instruments Inc.
//   Sep. 2017
//   Built with IAR Embedded Workbench v7.1
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>

// #defines for simple communication protocol
#define READ 0
#define WRITE 1

// #define for comparator voltage threshold
#define COMPTHR 43 // Comparator Vth = 1.5V * COMPTHR / 64 = 1V

// Data to be stored in FRAM and retained through power loss
// timeStamp is in POSIX time format (# of seconds since midnight 1 Jan. 1970)
// User needs to set the starting time with a WRITE TIME command
// (01h XXh XXh XXh XXh)
// READ TIME commands are answered by sending timeStamp, LSB first (timeStamp[0] first)

__persistent uint8_t timeStampFRAM[4] = {0};

// Global variables
uint8_t command;
__no_init uint8_t data;
__no_init uint8_t byteCount;
__no_init uint8_t timeStamp[4];
__no_init uint16_t readIV;

// Function prototypes
void UART_sendByte(uint8_t txByte);

/**
 * main.c
 */
void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

    byteCount = 0;              // Initialize byteCount

    // Configure eCOMP and Crystal Pin
    P1SEL0 = BIT1 | BIT6 | BIT7;// UCA0 RXD and TXD
    P1SEL1 = BIT1;              // Select eCOMP input function on P1.1/C1
    P2SEL1 |= BIT6 | BIT7;      // P2.6~P2.7: crystal pins

    PM5CTL0 &= ~LOCKLPM5;       // Disable the GPIO power-on default
    // high-impedance mode to activate previously
    // configured port settings

    // Configure internal 1.5V reference
    PMMCTL0_H = PMMPW_H;          // Unlock the PMM registers
    PMMCTL2 |= INTREFEN;          // Enable internal reference
    while(!(PMMCTL2 & REFGENRDY));// Poll till internal reference settles

    // Configure eCOMP
    CPCTL0 = CPPSEL0 | CPNSEL1 | CPNSEL2 | CPPEN | CPNEN;  // Select C1 as input for V+ terminal
                                                           // Select DAC as input for V- terminal
                                                           // Enable eCOMP input
    CPDACCTL = CPDACREFS | CPDACEN | CPDACBUFS;            // Select on-chip VREF and enable DAC
                                                           // CPDACSW bit selected as the buffer control source
    CPDACDATA = COMPTHR;                                   // CPDACBUF1 = On-chip VREF * COMPTHR / 64 = 1V (COMPTHR=43)
    CPCTL1 =  CPIIE | CPHSEL_3 | CPEN;                     // Enable fall edge interrupt, select 30mV hysteresis mode
                                                           // Turn on eCOMP, in high speed mode

    // Initialize crystal
    do
    {
        CSCTL7 = 0;             // Clear XT1 fault flag
        SFRIFG1 = 0;            // Clear fault flag
    } while (SFRIFG1 & OFIFG);  // Test oscillator fault flag
    CSCTL4 = SELA__XT1CLK;      // Set ACLK = XT1CLK = 32768Hz

    // Configure UART
    // From user's Guide Table of Baud Rates, 9600 baud at BRCLK = 32768
    // UCOS16 = 0
    // UCBRx = 3
    // UCBRFx = 0
    // UCBRSx = 0x92
    UCA0CTLW0 = UCSWRST | UCSSEL__ACLK;
    UCA0BRW = 3;
    UCA0MCTLW = 0x9200;
    UCA0CTLW0 &= ~UCSWRST;                   // Initialize eUSCI
    UCA0IE = UCRXIE;                         // Enable USCI_A0 RX interrupt

    // RTC count re-load compare value at 32768 for 1/sec interrupt
    RTCMOD = 32767;
    // Initialize and start RTC
    // Source = 32kHz crystal, interrupts enabled
    RTCCTL = RTCSS__XT1CLK | RTCSR | RTCPS__1 | RTCIE;

    while(1)
    {
        __bis_SR_register(LPM3_bits | GIE); // Go to LPM3 with interrupts
        __no_operation();

        // Process received byte
        // Note that byteCount is always incremented by 2. This allows
        // __even_in_range usage for space-saving compiler optimization.
        // See SLAU132 for more info.
        switch(__even_in_range(byteCount,10))
        {
        case 2:                 // 1st byte received
            command = data;     // 1st byte is always command byte

            if(command == READ) // Read Command
            {                   // Send response.
                UART_sendByte(timeStamp[0]); // Send the current time
                UART_sendByte(timeStamp[1]);
                UART_sendByte(timeStamp[2]);
                UART_sendByte(timeStamp[3]);
                byteCount = 0;  // No further bytes to receive for READ
            }
            break;

        case 4:                 // 2nd byte received
        case 6:                 // 3rd byte received
        case 8:                 // 4th byte received
        case 10:                // 5th byte received
            if(command == WRITE)
                timeStamp[(byteCount>>1)-2] = data;
            if(byteCount >= 10) // Check if all bytes received
                byteCount = 0;  // WRITE TIME command complete
            break;
        default: break;
        }
    }
}

// Function for sending UART byte via polling method
void UART_sendByte(uint8_t txByte)
{
    while(!(UCA0IFG & UCTXIFG));// Check if ready to TX
    UCA0TXBUF = txByte;         // Send the data byte
}

// RTC interrupt service routine
#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
    readIV = RTCIV;             // Clear interrupt flag
    (*(uint32_t*)timeStamp)++;  // Increment time
}

// UART interrupt service routine
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    data = UCA0RXBUF;   // Read the byte

    // Note that byteCount is always incremented by 2. This allows
    // __even_in_range usage in main() for space-saving compiler optimization.
    // See SLAU132 for info.
    byteCount+=2;       // Increment byte

    __bic_SR_register_on_exit(LPM3_bits);   // Wake from LPM
}

// eCOMP interrupt service routine
#pragma vector=ECOMP0_VECTOR
__interrupt void ECOMP0_ISR(void)
{
    readIV = CPIV;      // Clear interrupt flag
    SYSCFG0 = FRWPPW;   // Open FRAM for writes to timeStamp
    *(uint32_t*)timeStampFRAM = *(uint32_t*)timeStamp; // Store time stamp in FRAM
    SYSCFG0 = FRWPPW | PFWP;// FRAM write protected (not writable)
}

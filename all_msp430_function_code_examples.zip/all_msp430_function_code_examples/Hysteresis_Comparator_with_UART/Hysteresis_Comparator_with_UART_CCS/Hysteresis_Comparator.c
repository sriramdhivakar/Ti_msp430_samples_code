/* --COPYRIGHT--,BSD-3-Clause
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2x00 Demo - eCOMP Hysteresis with UART
//
//  Description: Use eCOMP and DAC with VCC as reference to determine if input
//  'Vcompare' is high or low. When Vcompare exceeds CPDACDATA_H COUT goes high
//  and when Vcompare is less than CPDACDATA_L then COUT goes low. In this example,
//  the UART can used to set the hysteresis value. At the same time, the hysteresis
//  value can be read out over UART by a host controller.
//
//  Communications Protocol (UART)
//  ----------------------------------------------------------------------
//  [READ/WRITE] <data> <data>
//  READ = 00h, WRITE = 01h,
//
//  WRITE DAC: 01h XXh XXh
//  READ DAC:  00h     RESPONSE: XXh XXh
//  ----------------------------------------------------------------------
//  XT1 requires a 32768Hz crystal oscillator for this example.
//  ACLK = XT1 = 32768Hz, MCLK = SMCLK = default DCODIV ~1.048MHz.
//
//                MSP430FR2000
//             ------------------
//         /|\|                  |
//          | |                  |
//          --|RST        P1.1/C1|<--Vcompare
//            |                  |
//            |         P2.0/COUT|----> 'high'(Vcompare>CPDACDATA_H); 'low'(Vcompare<CPDACDATA_L)
//            |                  |
//            |              P1.7|--> UCA0TXD
//            |              P1.6|<-- UCA0RXD
//            |                  |
//            |              P2.6|--> XOUT 32768 XTAL
//            |              P2.7|<-- XIN
//            |                  |
//
//   Cash Hao
//   Texas Instruments Inc.
//   Sept. 2017
//   Built with IAR Embedded Workbench v7.20 & Code Composer Studio v7.0
//******************************************************************************
#include <msp430.h>
#include <stdint.h>

// #defines for simple communication protocol
#define READ 0
#define WRITE 1

// Global variables
uint8_t command, data, byteCount;

// Function prototypes
void UART_sendByte(uint8_t txByte);

int main(void)
{
  WDTCTL = WDTPW | WDTHOLD;                 // Stop WDT

  byteCount = 0;                            // Initialize byteCount

  // Configure Comparator input & output
  P1SEL0 = BIT1 | BIT6 | BIT7;       // Select eCOMP input function on P1.1/C1, UCA0 RXD and TXD
  P1SEL1 = BIT1;
  P2DIR  = BIT0;
  P2SEL1 = BIT0 | BIT6 | BIT7;      //  Select CPOUT function on P2.0/COUT, P2.6~P2.7: crystal pins

  PM5CTL0 &= ~LOCKLPM5;                     // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings

  // Initialize crystal
  do
  {
      CSCTL7 = 0;             // Clear XT1 fault flag
      SFRIFG1 = 0;            // Clear fault flag
  } while (SFRIFG1 & OFIFG);  // Test oscillator fault flag
  CSCTL4 = SELA__XT1CLK;      // Set ACLK = XT1CLK = 32768Hz

  // Configure UART
  // From user's Guide Table of Baud Rates, 9600 baud at BRCLK = 32768
  // UCOS16 = 0
  // UCBRx = 3
  // UCBRFx = 0
  // UCBRSx = 0x92
  UCA0CTLW0 = UCSWRST | UCSSEL__ACLK;
  UCA0BRW = 3;
  UCA0MCTLW = 0x9200;
  UCA0CTLW0 &= ~UCSWRST;                   // Initialize eUSCI
  UCA0IE = UCRXIE;                         // Enable USCI_A0 RX interrupt


  // Setup eCOMP
  CPCTL0 = CPPSEL0;                         // Select C1 as input for V+ terminal
  CPCTL0 |= CPNSEL1 | CPNSEL2;              // Select DAC as input for V- terminal
  CPCTL0 |= CPPEN | CPNEN;                  // Enable eCOMP input
  CPDACCTL = CPDACEN;                       // eCOMP output is selected as the buffer control source
  CPDACDATA = 0x1030;                       // CPDACBUF1=VCC *3/4   CPDACBUF2=VCC *1/4
  CPCTL1 |= CPEN | CPMSEL;                  // Turn on eCOMP, in low power mode



  while(1)
  {
      __bis_SR_register(LPM3_bits | GIE); // Go to LPM3 with interrupts
      __no_operation();

      // Process received byte
      // Note that byteCount is always incremented by 2. This allows
      // __even_in_range usage for space-saving compiler optimization.
      // See SLAU132 for more info.
      switch(__even_in_range(byteCount,6))
      {
      case 2:                 // 1st byte received
          command = data;     // 1st byte is always command byte

          if(command == READ) // Read Command
          {                   // Send response.
              UART_sendByte(CPDACDATA_H); // Send the current DAC value
              UART_sendByte(CPDACDATA_L);
              byteCount = 0;  // No further bytes to receive for READ
          }
          break;

      case 4:                 // 2nd byte received
          if(command == WRITE)
              CPDACDATA_H = data;
          break;
      case 6:                 // 3rd byte received
          if(command == WRITE)
              CPDACDATA_L = data;
          if(byteCount >= 6) // Check if all bytes received
              byteCount = 0;  // WRITE TIME command complete
          break;
      default: break;
      }
  }

}

// Function for sending UART byte via polling method
void UART_sendByte(uint8_t txByte)
{
    while(!(UCA0IFG & UCTXIFG));    // Check if ready to TX
    UCA0TXBUF = txByte;             // Send the data byte
}

// UART interrupt service routine
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)

{
    data = UCA0RXBUF;   // Read the byte

    // Note that byteCount is always incremented by 2. This allows
    // __even_in_range usage in main() for space-saving compiler optimization.
    // See SLAU132 for info.
    byteCount+=2;       // Increment byte

    __bic_SR_register_on_exit(LPM3_bits);   // Wake from LPM
}


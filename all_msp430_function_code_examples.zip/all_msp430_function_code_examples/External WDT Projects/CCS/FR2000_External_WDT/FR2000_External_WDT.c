/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 External Watch-dog Timer
//
//  Description: MSP430FR2000 is implemented as an external WDT where the host
//  MCU must address the WDT within a specified time interval,
//  defaulted to 1.6 seconds. The WDT is addressed by sending a high/low
//  transition on the WDI input. Through UART, the host can alter the timeout
//  interval from 1 to 2 seconds in increments of .2 seconds. Selecting a
//  timeout value is done by sending a UART hex command or 0, 1, 2, 3, 4, or 5.
//  TimerB is used to count to the timeout value and sends a reset to the host
//  if the timeout value is reached.
//
//  A Manual Reset pin is implemented to send a reset to the host MCU manually.

//  With larger memory, a more robust WDT addressing protocol could be
//  established where a specific UART sequence can be requested by the FR2000
//  or sent to the host MCU prevent the host MCU reset.
//
//  Communications Protocol (UART)
//  ----------------------------------------------------------------------
//  ACLK = default REFO ~32768Hz, DCO = 16MHz, MCLK = 8MHz, SMCLK = 1MHz
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |           P1.3|--> MCU_RESET
//        |           P1.7|--> UCA0TXD
//        |           P1.6|<-- UCA0RXD
//        |               |
//        |           P1.1|<-- Manual Reset
//        |           P1.2|<-- WDI
//        |               |
//
//   Matthew Calvo
//   Texas Instruments Inc.
//   August 2017
//   Built with IAR Embedded Workbench v7.1 & Code Composer Studio v7.2
//******************************************************************************

#include <msp430.h> 
#include <stdint.h>

// #defines for UART timeout commands and reset pulse duration
#define TIMEOUT_MAX 5       //Max timeout selection value
#define RESET_CYCLES 8000
//Cycle duration of the host reset signal
//Initialized to 1ms using the 8MHz MCLK as the cycle count reference clock

// Function prototypes
void GPIO_sendReset();

//Lookup table for WDT timeout values
const uint16_t timeout[6] = {32768,39322,45875,52429,58982,65535};
//Pre-Set values of            1 ,  1.2 , 1.4 , 1.6 , 1.8 ,  2   seconds

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

    // Configure one FRAM waitstate as required by the device datasheet for
    // MCLK operation beyond 8MHz _before_ configuring the clock system.

    FRCTL0 = FRCTLPW | NWAITS_1;

    // Configure DCO for 16MHz, which defaults to source the SMCLK and MCLK
    __bis_SR_register(SCG0);          // disable FLL
    CSCTL3 |= SELREF__REFOCLK;        // Set REFO as FLL reference source
    CSCTL0 = 0;                       // clear DCO and MOD registers
    CSCTL1 &= ~(DCORSEL_7);           // Clear DCO frequency select bits first
    CSCTL5 |= DIVS_3 | DIVM0;         //Set MCLK = 8MHz and SMCLK = 1MHz
    CSCTL1 |= DCORSEL_5;              // Set DCO = 16MHz
    CSCTL2 = FLLD_0 + 487;            // DCOCLKDIV = 16MHz

    CSCTL4 = SELA__REFOCLK;           // Set ACLK = REFO = 32768Hz
    __delay_cycles(3);
    __bic_SR_register(SCG0);                    // enable FLL
    while(CSCTL7 & (FLLUNLOCK0 | FLLUNLOCK1));  // FLL locked

    // Configure GPIO
    P1SEL0 = BIT6 | BIT7;      // UCA0 RXD and TXD
    P1DIR = BIT3;              //Set P1.3 as output
    P1OUT = BIT3;              //Set P1.3 (reset) as high (active low)
    P1OUT =  BIT1 | BIT2;      // Configure P1.1(MR) and P1.2(WDI) as pulled-up
    P1REN =  BIT1 | BIT2;      // P1.1 and P1.2 pull-up register enable
    P1IES =  BIT1 | BIT2;      // P1.1 and P1.2 Hi--->Low edge

    // Disable the GPIO power-on default high-impedance mode
    // to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    //Enable GPIO Interrupts
    P1IFG &= ~(BIT1|BIT2);                 // P1.1 and P1.2 IFG cleared
    P1IE = BIT1 | BIT2;                    // P1.1 and P1.2 interrupt enabled

    // Configure UART
    // From user's Guide Table of Baud Rates, 9600 baud at BRCLK = 1MHz
    // UCOS16 = 1
    // UCBRx = 6
    // UCBRFx = 8
    // UCBRSx = 0x20
    UCA0CTLW0 = UCSWRST | UCSSEL__SMCLK;
    //Reset UART and set SMCLK as BRCLK source
    UCA0BRW = 6;
    UCA0MCTLW = 0x2081 ;
    UCA0CTLW0 &= ~UCSWRST;                   // Initialize eUSCI
    UCA0IE = UCRXIE;                         // Enable USCI_A0 RX interrupt

    //Configure TimerB sourced by ACLK=32768Hz
    TB0CCTL0 |= CCIE;                   // TBCCR0 interrupt enabled
    TB0CCR0 = 52429;
    // Set the default delay compare value to 1.6 sec
    TB0CTL |= TBSSEL__ACLK | MC__UP;    // ACLK, up mode

    SFRIE1 |= WDTIE;              // Enable WDT interrupt

    while(1)
    {
        __bis_SR_register(LPM3_bits | GIE); // Go to LPM3 with interrupts
        __no_operation();                   //for debug purposes
    }
}

// UART interrupt service routine
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    uint8_t data;
    data = UCA0RXBUF;          // Read incoming UART data
    if(data <= TIMEOUT_MAX)    //Change the timeout value if selection is valid
    {
        TB0CCR0 = timeout[data];  //Set the delay to the selected timeout value
    }
    TB0CTL |= TBCLR;
    //Regard UART communication as WDT addressing and restart the timer
}

// GPIO Interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    if ( P1IFG & P1IV1 )        //P1.1 Interrupt Flag pending (Manual Reset)
    {
        P1IFG &= ~BIT1;         // Clear P1.1 IFG
        GPIO_sendReset();       //Send reset signal to host MCU
        TB0CTL |= TBCLR;        //Restart the timer
    }

    if ( P1IFG & P1IV2 )        //P1.2 Interrupt Flag pending (WDI pin)
    {
        P1IFG &= ~BIT2;         // Clear P1.2 IFG
        TB0CTL |= TBCLR;        //Restart the timer
    }

    //Prevent voltage bouncing from firing multiple ISR's
    P1IE &= ~(BIT1 | BIT2);       // P1.1 and P1.2 interrupt disabled
    //Start WDT interval timer of 250ms, ACLK source
    WDTCTL = WDTPW |  WDTTMSEL | WDTCNTCL | WDTIS2 | WDTSSEL0 | WDTIS0;
}

// Watchdog Timer interrupt service routine
#pragma vector = WDT_VECTOR
__interrupt void WDT_ISR(void)
{
    P1IFG &= ~(BIT1|BIT2);                 //clear the GPIO interrupt flags
    P1IE = BIT1 | BIT2;                    //P1.1 and P1.2 interrupt enabled
    WDTCTL = WDTPW | WDTHOLD;              //Stop watchdog timer
}


// Timer B0 interrupt service routine
#pragma vector = TIMER0_B0_VECTOR
__interrupt void Timer_B (void)
{
    GPIO_sendReset();       //Send reset signal to host MCU
    TB0CCTL0 &=  ~(BIT0);   //Clear the CCIFG interrupt flag
}

// Function for sending reset signal
void GPIO_sendReset()
{
    P1OUT &= ~(BIT3);       //Send a low signal
    __delay_cycles(RESET_CYCLES);
    //Wait n cycles for the reset signal to be acknowledged
    P1OUT |= BIT3;          //Send a high signal
}

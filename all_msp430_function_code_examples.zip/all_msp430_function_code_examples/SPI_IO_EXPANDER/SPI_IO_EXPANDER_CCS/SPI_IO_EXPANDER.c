/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//   MSP430FR2000 SPI IO Expander
//
//   Description: Demonstrate a simple IO Expander with 4-wire SPI interface.
//   The master controller can send message to slave(FR2000) to expand to 8 
//   ports IOs which are mapping to P1.0~1.3, P2.0~2.1, P2.6~2.7 of FR2000 
//   pins. The master can set the direction/output of the ports and read the
//   input state if ports are setting for input pin.
//
//   The SPI configuration of host processor:
//       4-pin SPI with STE active low;
//       Clock polarity inactive state high;
//       Data is changed on the first UCLK edge and captured on the following edge;
//       MSB first, 8-bit character length
//
//                                    MSP430FR2000
//                                  -----------------
//                              /|\|                 |
//                               | |                 |
//                               --|RST          P1.0|<->Pin0
//                                 |             P1.1|<->Pin1
//                                 |             P1.2|<->Pin2
//         Slave Select (UCA0STE)->|P1.4         P1.3|<->Pin3
//         Serial Clock (UCA0CLK)->|P1.5         P2.0|<->Pin4
//             Data In (UCA0SOMI)<-|P1.6         P2.1|<->Pin5
//            Data Out (UCA0SIMO)->|P1.7         P2.6|<->Pin6
//                                 |             P2.7|<->Pin7
//                                 |                 |
//                                 |                 |
//
//
// Wei Zhao
// Texas Instruments Inc.
// September 2017
// Built with Code Composer Studio Version: 7.1 & IAR Embedded Workbench v7.10.4
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

//------------------------------------------------------------------------------
// Definitions
//------------------------------------------------------------------------------
#define NO_MESSAGE     0x00                        // no message
#define START_MESSAGE  0x0F                        // start with the first byte of message
#define STOP_MESSAGE   0xF0                        // stop with the second byte of message

#define NO_COMMAND     0x00                        // no command
#define OUT_COMMAND    0x20                        // Write-OUT Command
#define DIR_COMMAND    0x10                        // Write-DIR Command
#define READ_COMMAND   0x80                        // Read Command

#define NO_DATA        0x00                        // No Data

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------
#if defined (__TI_COMPILER_VERSION__)
volatile uint8_t masterCommand;                    // Stores master command
volatile uint8_t masterData;                       // Stores master data
volatile uint8_t slaveData;                        // Stores slave data
volatile uint8_t messageStatus;                    // Stores message status
volatile uint8_t tempP1Data;
volatile uint8_t tempP2Data;

#elif defined (__IAR_SYSTEMS_ICC__)
__no_init volatile uint8_t masterCommand;          // Stores master command
__no_init volatile uint8_t masterData;             // Stores master data
__no_init volatile uint8_t slaveData;              // Stores slave data
__no_init volatile uint8_t messageStatus;          // Stores message status
__no_init volatile uint8_t tempP1Data;
__no_init volatile uint8_t tempP2Data;
#endif



//------------------------------------------------------------------------------
// Declare functions
//------------------------------------------------------------------------------
void SPI_init(void)
{
    P1SEL0 |= BIT4 | BIT5 | BIT6 | BIT7;           // set 4-SPI pin as second function
  
    UCA0CTLW0 |= UCSWRST;                          // **Put state machine in reset**
                                                   // 4-pin, 8-bit SPI slave
    UCA0CTLW0 |= UCSYNC|UCCKPL|UCMSB|UCMODE_2|UCSTEM|UCSSEL__SMCLK;
                                                   // SPI mode is selected when the UCSYNC bit is set
                                                   // Clock polarity inactive state high
                                                   // MSB first, 8-bit character length
                                                   // 4-pin SPI with STE active low
                                                   // STE pin generates the enable signal for 4-wire slave
                                                   // eUSCI clock source select SMCLK
    UCA0BR0 = 0x01;                                // Bit clock prescaler setting: BRCLK = SMCLK/1
    UCA0MCTLW = 0;                                 // clear MCTLW when using SPI mode for eUSCI_A
    UCA0CTLW0 &= ~UCSWRST;                         // **Initialize USCI state machine**
    UCA0IE |= UCRXIE;                              // Enable USCI_A0 RX interrupt
}

void Master_dataMapping(void)
{
    tempP1Data = masterData & 0x0F;
    tempP2Data = (masterData & 0xC0) | ((masterData >> 4) & 0x03);
}

//------------------------------------------------------------------------------
// Main function
//------------------------------------------------------------------------------
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;                      // Stop watchdog timer

    SPI_init();

    // Disable the GPIO power-on default high-impedance mode
    // to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    messageStatus = NO_MESSAGE;
    slaveData = NO_DATA;

    while(1)
    {
        __bis_SR_register(LPM3_bits | GIE);        // Enter LPM3 and wait for interrupt

        if(masterCommand == DIR_COMMAND)           // Write-DIR Command
        {
            Master_dataMapping();
            P1DIR = tempP1Data;                    // set the P1DIR register
            P2DIR = tempP2Data;                    // set the P2DIR register
        }
        else if (masterCommand == OUT_COMMAND)     // Write-OUT Command
        {
            Master_dataMapping();
            P1OUT = tempP1Data;                    // set the P1OUT register
            P2OUT = tempP2Data;                    // set the P2OUT register
        }
        else if (masterCommand == READ_COMMAND)    // Read Command
        {
            tempP1Data = P1IN & 0x0F;
            tempP2Data = (P2IN & 0xC0) | ((P2IN & 0x03) << 4);
            slaveData = tempP1Data | tempP2Data;   // save P1IN&P2IN register to slaveData
            UCA0IE |= UCTXIE;                      // enable TX interrupt
            UCA0IFG = UCTXIFG;                     // trigger TXIFG to transmit the slaveData
        }
        messageStatus = NO_MESSAGE;

    }
}

//------------------------------------------------------------------------------
// The USCI_A0 ISR is used to check the necessary protocol and either reads or
// transfers data back to the host processor
//------------------------------------------------------------------------------
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
#else
#error Compiler not supported!
#endif
{
  switch(__even_in_range(UCA0IV,USCI_SPI_UCTXIFG))
  {
    case USCI_NONE: break;                         // Vector 0 - no interrupt
    case USCI_SPI_UCRXIFG:
           if(messageStatus == NO_MESSAGE)
           {
            masterCommand = UCA0RXBUF;             // save Master Command
            messageStatus = START_MESSAGE;         // Start of the message
           }
           else if(messageStatus == START_MESSAGE)
           {
            masterData = UCA0RXBUF;                // save Master Data
            messageStatus = STOP_MESSAGE;          // Stop of the message
           }

           UCA0IFG &= ~UCRXIFG;
           if(messageStatus == STOP_MESSAGE)
           {
            __bic_SR_register_on_exit(LPM3_bits);  // Wake up for message actions
           }           
           break;
    case USCI_SPI_UCTXIFG:
          UCA0TXBUF = slaveData;                   // Transmit slave data
          UCA0IE &= ~UCTXIE;                       // disable TX interrupt
          break;
    default: break;
  }
}

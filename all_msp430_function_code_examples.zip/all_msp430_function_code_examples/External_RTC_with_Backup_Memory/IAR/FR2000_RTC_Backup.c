/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 RTC Time-stamp with Backup Memory
//
//  Description: RTC time-stamping and backup memory accessible through UART.
//  The MSP430 uses the RTC counter module to increment the timestamp 1/sec.
//  The UART should be used to set an initial time at first startup and the
//  RTC will increment from there. The timestamp is in POSIX time format.
//  The timestamp can be read out over UART by a host controller, so the MSP430
//  is acting as an external RTC to keep time.
//
//  16 bytes of FRAM memory is also allocated as backup memory. The host can
//  read and write this backup memory over UART and use it to store backup data
//  that it wants to be retained through a system power loss.
//
//  Because the timestamp and backup memory is stored in FRAM, it will be
//  retained through a
//  power loss.
//
//  Communications Protocol (UART)
//  ----------------------------------------------------------------------
//  [READ/WRITE] [ADDRESS] <data> <data> <data> <data>
//  READ = 00h, WRITE = 01h, ADDRESS = backup mem 00-0Fh, or FFh for RTC
//
//  WRITE TIME: 01h FFh XXh XXh XXh XXh
//  READ TIME:  00h FFh     RESPONSE: XXh XXh XXh XXh
//  WRITE MEM:  01h 00-0Fh XXh
//  READ MEM:   00h 00-0Fh  RESPONSE: XXh
//  ----------------------------------------------------------------------
//
//  XT1 requires a 32768Hz crystal oscillator for this example.
//  ACLK = default REFO ~32768Hz, MCLK = SMCLK = default DCODIV ~1.048MHz.
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |               |
//        |           P1.7|--> UCA0TXD
//        |           P1.6|<-- UCA0RXD
//        |               |
//        |           P2.6|--> XOUT 32768 XTAL
//        |           P2.7|<-- XIN
//        |               |
//
//   Katie Pier
//   Texas Instruments Inc.
//   August 2017
//   Built with IAR Embedded Workbench v7.1 & Code Composer Studio v7.2
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>

// #defines for simple communication protocol
#define READ 0
#define WRITE 1
#define TIME_ADDRESS 255

// Data to be stored in FRAM and retained through power loss
// timeStamp is in POSIX time format (# of seconds since midnight 1 Jan. 1970)
// User needs to set the starting time with a WRITE TIME command
// (01h FFh XXh XXh XXh XXh)
// READ TIME commands are answered by sending timeStamp, LSB first (timeStamp[0]
// first)
__persistent uint8_t timeStamp[4] = {0};
__persistent uint8_t backupMem[16] = {0};

// Global variables
__no_init uint8_t command, data, address, byteCount;

// Function prototypes
void UART_sendByte(uint8_t txByte);

/**
 * main.c
 */
void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

    byteCount = 0;              // Initialize byteCount

    // Configure GPIO
    P1SEL0 = BIT6 | BIT7;       // UCA0 RXD and TXD
    P2SEL1 |= BIT6 | BIT7;      // P2.6~P2.7: crystal pins

    PM5CTL0 &= ~LOCKLPM5;       // Disable the GPIO power-on default
                                // high-impedance mode to activate previously
                                // configured port settings
    // Initialize crystal
    do
    {
        CSCTL7 = 0;             // Clear XT1 fault flag
        SFRIFG1 = 0;            // Clear fault flag
    } while (SFRIFG1 & OFIFG);  // Test oscillator fault flag
    CSCTL4 = SELA__XT1CLK;      // Set ACLK = XT1CLK = 32768Hz

    // Configure UART
    // From user's Guide Table of Baud Rates, 9600 baud at BRCLK = 32768
    // UCOS16 = 0
    // UCBRx = 3
    // UCBRFx = 0
    // UCBRSx = 0x92
    UCA0CTLW0 = UCSWRST | UCSSEL__ACLK;
    UCA0BRW = 3;
    UCA0MCTLW = 0x9200;
    UCA0CTLW0 &= ~UCSWRST;                   // Initialize eUSCI
    UCA0IE = UCRXIE;                         // Enable USCI_A0 RX interrupt

    SYSCFG0 = FRWPPW;   // Open FRAM for writes to timeStamp and backupMem

    SYSCFG2 = RTCCKSEL; // Set RTC CLK to ACLK

    // RTC count re-load compare value at 32768 for 1/sec interrupt
    RTCMOD = 32767;
    // Initialize and start RTC
    // Source = 32kHz crystal, interrupts enabled
    RTCCTL = RTCSS_1 | RTCSR | RTCPS__1 | RTCIE;

    while(1)
    {
        __bis_SR_register(LPM3_bits | GIE); // Go to LPM3 with interrupts
        __no_operation();

        // Process received byte
        // Note that byteCount is always incremented by 2. This allows
        // __even_in_range usage for space-saving compiler optimization.
        // See SLAU132 for more info.
        switch(__even_in_range(byteCount,12))
        {
            case 2:                 // 1st byte received
                command = data;     // 1st byte is always command byte
                break;

            case 4:                 // 2nd byte received
                address = data;     // 2nd byte is always address byte

                if(command == READ) // For Read commands, 2nd byte is last byte.
                {                   // Send response.
                    if(address == TIME_ADDRESS) // READ TIME command
                    {
                        UART_sendByte(timeStamp[0]); // Send the current time
                        UART_sendByte(timeStamp[1]);
                        UART_sendByte(timeStamp[2]);
                        UART_sendByte(timeStamp[3]);
                    }
                    else                        // READ MEM command
                    {
                        UART_sendByte(backupMem[address]);  //Send data
                    }
                    byteCount = 0;  // No further bytes to receive for READ
                }
                break;

            case 6:
            case 8:
            case 10:
            case 12:    // 3rd, 4th, 5th, or 6th byte received
                        // Only WRITE commands receive more than 2 bytes
                if(address == TIME_ADDRESS)     // WRITE TIME command
                    timeStamp[(byteCount>>1)-3] = data;
                else                            // WRITE MEM command
                {
                    if(address < 16)                // Check for valid address
                        backupMem[address] = data;  // Write to backup memory
                    byteCount = 0;                  // WRITE MEM done
                }

                if(byteCount >= 12)             // Check if all bytes received
                    byteCount = 0;              // WRITE TIME command complete
                break;
            default: break;
        }
    }
}

// Function for sending UART byte via polling method
void UART_sendByte(uint8_t txByte)
{
    while(!(UCA0IFG & UCTXIFG));    // Check if ready to TX
    UCA0TXBUF = txByte;             // Send the data byte
}

// RTC interrupt service routine
#pragma vector=RTC_VECTOR
__interrupt void RTC_ISR(void)
{
    RTCIV = 0;                  // Clear interrupt flag
    (*(uint32_t*)timeStamp)++;  // Increment time
}

// UART interrupt service routine
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    data = UCA0RXBUF;   // Read the byte

    // Note that byteCount is always incremented by 2. This allows
    // __even_in_range usage in main() for space-saving compiler optimization.
    // See SLAU132 for info.
    byteCount+=2;       // Increment byte

    __bic_SR_register_on_exit(LPM3_bits);   // Wake from LPM
}

/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//   MSP430FR2000 SPI EEPROM emulator
//
//   Description: Demonstrate EEPROM functionality with simple read/write
//   commands and 8-bit memory address space.  Timing and low-power
//   optimizations have not been includes so that enough FRAM could be allocated
//   for EEPROM memory on a MSP430FR2000 device.  Please see the associated
//   documentation for more details
//
//
//                   MSP430FR2000
//                 -----------------
//             /|\|                 |
//              | |                 |
//              --|RST              |
//                |                 |
//                |             P1.7|-> Data OUT (UCA0SIMO)
//                |                 |
//                |             P1.6|<- Data IN  (UCA0SOMI)
//                |                 |
//                |             P1.5|-> Serial Clock Out (UCA0CLK)
//                |                 |
//                |             P1.4|<- Write Protect (GPIO)
//                |                 |
//                |             P1.3|<- Chip Select (Interrupt-capable GPIO)
//
//
// R. Brown
// Texas Instruments Inc.
// July 2017
// Built with IAR Embedded Workbench Version: 7.1
//******************************************************************************

#include "io430.h"
#include <stdint.h>

//------------------------------------------------------------------------------
// Definitions
//------------------------------------------------------------------------------
#define OPCODE_READ     0x03                // Read command
#define OPCODE_WRITE    0x02                // Write command
#define WP              BIT4                // P1.4 is Write Protect
#define CS              BIT3                // P1.3 is Chip Select
#define CLK             BIT5                // P1.5 is SPI clock
#define SOMI            BIT6                // P1.6 is SPI SOMI
#define SIMO            BIT7                // P1.7 is SPI SIMO

//------------------------------------------------------------------------------
// Global variables
//------------------------------------------------------------------------------
__persistent uint8_t spiOpCode = 0;         // Stores op code information
__persistent uint8_t eepromRxData = 255;    // Buffer to store received data

//#pragma location=0xFF58                   // Define EEPROM location  
// Initializae EEPROM data
__persistent uint8_t eeprom1[48] = {\
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, \
        0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, \
        0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, \
        0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, \
        0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, \
        0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F};

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer

    PAOUT = CS;                             // Configure P1.3 as pulled-up
    PADIR = 0xFFF7;
    PAREN = 0xFFFF;                         // P1.3 pull-up register enable
    PAIES = CS;                             // P1.3 Hi/Low edge
    PAIE = CS;                              // P1.3 interrupt enabled

    // Disable the GPIO power-on default high-impedance mode
    // to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;                     

    // Initialize the serial communication interface
    P1SEL0 |= CLK | SOMI | SIMO;              // set 3-SPI pin as second function

    UCA0CTLW0 |= UCSWRST;                     // **Put state machine in reset**
    UCA0CTLW0 |= UCSYNC|UCCKPL|UCMSB;         // 3-pin, 8-bit SPI slave
                                              // Clock polarity high, MSB
    UCA0CTLW0 |= UCSSEL__ACLK;                // UCLK

    while(1)
    {
         __bis_SR_register(LPM3_bits | GIE);  // Enter LPM3 and wait for interrupt
        __no_operation();
    }
}

//------------------------------------------------------------------------------
// The USCI_A0 ISR is used to check the necessary protocol and either reads or
// transfers data back to the host processor
//------------------------------------------------------------------------------
#pragma vector=EUSCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    SYSCFG0 = FRWPPW;                               // FRAM write enable
    switch(__even_in_range(UCA0IV, UCIV__UCTXIFG))
    {
    case UCIV__NONE:         break;                  // Vector 0: No interrupts
    case UCIV__UCRXIFG:                          // Vector 2: UCRXIFG
        if(spiOpCode == 0)                          // First received byte since reset is Op code
            spiOpCode = UCA0RXBUF;
        else if(spiOpCode == OPCODE_WRITE)          // Write command
        {
            if(eepromRxData == 0xFF)
                eepromRxData = UCA0RXBUF;           // Set the address accordingly
            else if(!(P1IN & WP))                   // Only write if WP pin is low
                eeprom1[eepromRxData++] = UCA0RXBUF;// Write the value to the index pointer register
            else
                UCA0IE &= ~(UCRXIE);                // If error, exit write mode and wait for reset
        }
        else if(spiOpCode == OPCODE_READ)           // Read command
        {
            if(eepromRxData == 0xFF)                // Check if the address has been received first
            {
                eepromRxData = UCA0RXBUF;           // Set the address accordingly
                if(eepromRxData <= 127)             // If the address is valid, prepare for sending data
                {
                    UCA0IE &= ~UCRXIE;              // Disable receive interrupt enable
                    UCA0IE |= UCTXIE;               // Enable transmit interrupt
                    UCA0TXBUF = eeprom1[eepromRxData++];// Preload the data here
                }
            }
        }
        break;
    case UCIV__UCTXIFG:                          // Vector 4: UCTXIFG
        if (eepromRxData <= 127)                    // Valid address to send data
            UCA0TXBUF = eeprom1[eepromRxData++];    // Populate TXBUF
        else UCA0IE &= ~UCTXIE;                     // Disable transmit interrupt
        break;
    default: break;
    }
    SYSCFG0 = FRWPPW | PFWP;                        // FRAM write disable
}

//------------------------------------------------------------------------------
// Port 1 interrupt service routine.
// Uses P1.3 for CS
//------------------------------------------------------------------------------
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    if(P1IES & CS)                                  // If high-to-low transition
    {
        UCA0IFG &= ~(UCRXIFG + UCTXIFG);            // Clear interrupt flags
        UCA0CTLW0 &= ~UCSWRST;                      // **Initialize USCI state machine**
        UCA0IE &= ~UCTXIE;                          // Disable transmit interrupt
        UCA0IE |= UCRXIE;                           // Enable USCI_A0 RX interrupt

        SYSCFG0 = FRWPPW;                           // FRAM write enable
        spiOpCode = 0x00;                           // Reset SPI Op Code
        eepromRxData = 0xFF;                        // Reset received data
        SYSCFG0 = FRWPPW | PFWP;                    // FRAM write disable

        P1IES &= ~CS;                               // Configure CS pin as low to high transition
    }
    else                                            // Means a low-to-high transition occurred
    {
        P1IES |= CS;                                // Configure CS pin as high to low transition
        UCA0CTLW0 |= UCSWRST;                       // **Put state machine in reset**
    }
    P1IFG &= ~CS;                                   // Clear IFG
}

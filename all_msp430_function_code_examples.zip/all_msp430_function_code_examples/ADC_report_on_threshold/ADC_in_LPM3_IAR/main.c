/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2100 Demo - Ultra-Low Power Window Comparator
//
//  Description: This example sets up the ADC to monitor an analog input
//  continuously while in LPM3, and to set a GPIO and start transmitting ADC
//  conversion data over UART when a high threshold is reached by the ADC. UART
//  communication also allows the user to change the threshold
//  value.
//  ACLK = default REFO ~32768Hz
//
//           MSP430FR2100
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |          P1.6 |<--- UART TX
//        |               |
//        |          P1.7 |---> UART RX
//        |               |
//        |          P1.3 |<--- A3
//        |               |
//        |          P1.0 |---> GPIO
//
//   Nathan Siegel
//   Texas Instruments Inc.
//   September 2017
//   Built with Code Composer Studio v7.2 and IAR 7.10
//******************************************************************************
#include <msp430.h> 
#include <stdint.h>

#define GPIO_ALL        BIT0|BIT1|BIT2|BIT3|BIT4|BIT5|BIT6|BIT7

// Declare global variables
__no_init volatile uint8_t uartByteNum;           // 0 for high, 1 for low
__persistent uint16_t highThreshold = 0x01FF;     // High threshold for ADC

/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer

	//Initialize globals
	uartByteNum = 0;

	// Initialize ports
    P1OUT = 0;                                 // Set all pins low
    P1DIR = GPIO_ALL;                          // Set all pins as outputs

    P2OUT = 0;                                 // Set all pins low
    P2DIR = GPIO_ALL;                          // Set all pins as outputs

	// Initialize GPIOs
    P1SEL0 |= BIT3;                            //  Set A3 for ADC
    P1SEL1 |= BIT3;

    // Disable the GPIO power-on default high-impedance
    // mode to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    // Initialize UART
    P1SEL0 |= BIT6 | BIT7;                    // Configure P1.6 and P1.7 for UART

    // Configure UART
    // From user's Guide Table of Baud Rates, 9600 baud at BRCLK = 32768
    // UCOS16 = 0
    // UCBRx = 3
    // UCBRFx = 0
    // UCBRSx = 0x92
    UCA0CTLW0 = UCSWRST | UCSSEL__ACLK; // Use ACLK as source
    UCA0BRW = 3;                        // Baud rate of 9600
    UCA0MCTLW = 0x9200;
    UCA0CTLW0 &= ~UCSWRST;              // Initialize eUSCI
    UCA0IE = UCRXIE;                    // Enable USCI_A0 RX interrupt

    // Initialize Timer_B
    TB0CTL |= TBSSEL__ACLK;             // Use ACLK as source
    TB0CCR0 = 32768;                    // 1 sec for ACLK = 32768 Hz
    TB0CCTL0 |= CCIE;                   // Enable capture and compare interrupts

	// Initialize ADC
	ADCCTL0 |= ADCMSC_1 | ADCON;              // Conversions performed automatically
	                                          // ADC turned on

	ADCCTL1 |= ADCSHP_1 | ADCSSEL_1 | ADCCONSEQ_2; // Use input signal
	                                               // ADC clock source is ACLK
	                                               // ADC conversion mode = repeat-single-channel

	ADCMCTL0 |= ADCINCH_3;                     // Input channel set to A3
	ADCHI = highThreshold;                     // Set the high threshold
	ADCIE |= ADCHIIE_1;                        // Above upper threshold interrupt enabled

    ADCCTL0 |= ADCSC | ADCENC;                 // Enable and start conversion

    __bis_SR_register(LPM3_bits | GIE);        // Go to LPM3 with interrupts
    __no_operation();
}

/**
* ADC interrupt service routine
*/

#pragma vector=ADC_VECTOR
__interrupt void ADC_ISR(void)
{
    ADCIFG &= ~ADCHIIFG_1;                    // Clear interrupt flag
    P1OUT |= BIT0;                            // Set P1.0
    ADCIE &= ~ADCHIIE_1;                      // Disable interrupts
    TB0CTL |= MC__CONTINOUS;                  // Start TIMER_B
}

/**
* Timer_B interrupt service routine
*/

#pragma vector=TIMER0_B0_VECTOR
__interrupt void TIMER_B_ISR(void)
{
    TB0CTL &= ~CCIFG;                         // CLear interrupt flag

    // Send ADC conversion result over UART
    UCA0TXBUF = ADCMEM0_H;                    // Send high byte
    while(!(UCA0IFG&UCTXIFG));
    UCA0TXBUF = ADCMEM0_L;                    // Send low byte
}

/**
* eUSCI interrupt service routine
*/

#pragma vector=EUSCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
    {
        case USCI_UART_UCRXIFG:

            SYSCFG0 = FRWPPW;                         // FRAM write enable
            if(!uartByteNum)                          // High UART byte
            {
                ADCCTL0 &= ~ADCSC & ~ADCENC;          // Stop ADC until low byte received
                highThreshold = UCA0RXBUF << 8;       // Store received byte
                uartByteNum = 1;                      // Prepare to receive low byte
            }
            else                                      // Low UART byte
            {
                ADCCTL0 |= ADCSC | ADCENC;            // Resume ADC operation
                highThreshold += UCA0RXBUF;           // Store received byte
                ADCHI = UCA0RXBUF;                    // Set new high threshold
                uartByteNum = 0;                      // Prepare to receive high byte
            }
            SYSCFG0 = FRWPPW | PFWP;                  // FRAM write disable
            break;
        default: break;
    }

}

/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430FR2000 Reset Controller with WDT
//
//  Description: MSP430FR2000 is implemented as a reset control which can generate
//  hard reset and soft reset signal for processor. There is one button connected
//  to MSP430FR2000, if the button is pressed < 0.5s, a soft reset pulse is output
//  to the processor's interrupt pin, processor can do soft reset through firmware.
//  If the button is pressed >= 1s, a hard reset pulse is output to processer's
//  reset pin. The button press time and reset pulse time is defined by Macro which
//  can be easily modified by users based on different application requirement.
//  The reset controller achieves ~0.6uA ultra-low standby power consumption.
//
//  ----------------------------------------------------------------------
//  ACLK = default REFO ~32768Hz, DCO = 2MHz, MCLK = 1MHz, SMCLK = 1MHz
//
//           MSP430FR2000
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST            |
//        |           P1.0|--> Soft reset pulse (button press < 0.5s)
//        |           P1.2|--> Hard reset pulse (button press >= 1s )
//        |               |
//        |               |
//        |           P1.1|<-- Button
//        |               |
//        |               |
//
//   Darren Lu
//   Texas Instruments Inc.
//   Sep. 2017
//   Built with IAR Embedded Workbench v7.1 & Code Composer Studio v7.2
//******************************************************************************

#include <msp430.h>
#include <stdint.h>

/* User Macro Definitions */
#define  BUTTON     BIT1  // Set P1.1 for Button
#define  BUTTONIN   P1IN
#define  BUTTONOUT  P1OUT
#define  BUTTONIE   P1IE
#define  BUTTONIES  P1IES
#define  BUTTONREN  P1REN
#define  BUTTONIFG  P1IFG

#define  RSTOUT     P1OUT // Reset output port
#define  SWRST      BIT0  // Hard reset output pin
#define  HWRST      BIT2  // Soft reset output pin

#define  SHORTTIMECNT 2   // 250ms *2 = 0.5s, if button is pressed < 0.5s, output soft reset pulse
#define  LONGTTIMECNT 4   // 250ms *4 = 1s, if button is pressed >= 1s, output hard reset pulse
#define  SWRSTWIDTH 2000  // Soft reset pulse time = 2000 *30.5us = 61ms
#define  HWRSTWIDTH 2000  // Hard reset pulse time = 2000 *30.5us = 61ms

#define  DEBOUNCE   327   // Button debounce time = 327 * 30.5us = 10ms

/* Global Variable Declarations */
uint8_t WDT_cnt;          // Counter for WDT interval interrupt
uint8_t interruptEdge;    // Button pin interrupt edge selection
uint8_t buttonValue;      // Button pin voltage level, high->1, low->0

/* Local Function Declarations */
static inline void TB0_delay(uint16_t clkcnt); // Delay time function based on TimerB

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;               // stop watchdog timer

    // Port output low
    PAOUT = 0;
    PADIR = 0xffff;

    PM5CTL0 &= ~LOCKLPM5;                   // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings
    // BUTTON as interrupt
    BUTTONOUT |= BUTTON;                    // Set internal pull resistor as pull-up
    BUTTONREN |= BUTTON;                    // Enable internal pull resistor
    BUTTONIES |= BUTTON;                    // H to L transition for interrupt
    BUTTONIE |= BUTTON;                     // Enable BUTTON interrupt
    BUTTONIFG = 0;                          // Clear port IFG

    while(1)
    {
        __bis_SR_register(LPM4_bits | GIE); // Enter LPM4, enable global IE

        BUTTONIES &= ~BUTTON;               // L to H transition for interrupt
        WDT_cnt = 0;                        // Clear counter for WDT interval interrupt
        SFRIFG1 &= ~WDTIFG;                 // Clear WDT interrupt flag
        //Start WDT interval timer of 250ms, ACLK source, ACLK = REFO by default
        WDTCTL = WDTPW |  WDTTMSEL | WDTCNTCL | WDTIS2 | WDTSSEL0 | WDTIS0;
        SFRIE1 |= WDTIE;                    // Enable WDT interrupt

        __bis_SR_register(LPM3_bits);       // WDT in interval mode with ACLK in LPM3

        BUTTONIES |= BUTTON;                // H to L transition for interrupt
        WDTCTL = WDTPW | WDTHOLD;           // Stop watchdog timer
        if(WDT_cnt < SHORTTIMECNT)          // Short time button press
        {
            RSTOUT |= SWRST;                // Output soft reset pulse
            TB0_delay(SWRSTWIDTH);
            RSTOUT &= ~SWRST;
        }
        else if(WDT_cnt >= LONGTTIMECNT)    // Long time button press
        {
            RSTOUT |= HWRST;                // Output hard reset pulse
            TB0_delay(HWRSTWIDTH);
            RSTOUT &= ~HWRST;
        }
    }
}

// Use TimerB in up mode to generate configurable delay time
// Parameter clkcnt is the 32768Hz ACLK clock cycle number
// Delay time(s) = clkcnt / 32768
static inline void TB0_delay(uint16_t clkcnt)
{
    TB0CCR0 = clkcnt;                      // Set CCR0 counter
    TB0CCTL0 &= ~CCIFG;                    // Clear CCIFG
    TB0CTL = TBSSEL_1 | MC_1 | TBCLR;      // SRC = ACLK, Up mode
    while(!(TB0CCTL0 & CCIFG));            // Poll until timer counts to CCR0
    TB0CTL = 0;                            // Stop the timer
}

// PORT1 interrupt service routine
#pragma vector=PORT1_VECTOR
__interrupt void P1_ISR(void)
{
    if(BUTTONIFG & BUTTON)                 // Check Button IFG
    {
        BUTTONIFG = 0;                     // Clear Button IFG
        TB0_delay(DEBOUNCE);               // Button debounce time = 327 * 30.5us = 10ms
        interruptEdge = BUTTONIES & BUTTON;// Check current interrupt edge setting
        buttonValue = BUTTONIN & BUTTON;   // Check button pin voltage level
        if((interruptEdge == BUTTON) && (buttonValue == 0))      // If button pressed
        {
            __bic_SR_register_on_exit(LPM4_bits); // Exit LPM4
        }
        else if((interruptEdge == 0) && (buttonValue == BUTTON)) // If button released
        {
            __bic_SR_register_on_exit(LPM3_bits); // Exit LPM3
        }
    }
}

// Watchdog Timer interrupt service routine
#pragma vector = WDT_VECTOR
__interrupt void WDT_ISR(void)
{
    WDT_cnt++;                             // Counter for WDT interval interrupt
}                                          // WDT interval = 250ms
